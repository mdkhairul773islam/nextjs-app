import { BiSolidDashboard, BiSolidContact } from "react-icons/bi";
import { FaBlog, FaServicestack } from "react-icons/fa";
import { AiOutlineFundProjectionScreen } from "react-icons/ai";
import { MdOutlineCastForEducation, MdSettingsSuggest } from "react-icons/md";
import { TbMoneybag, TbReportMoney } from "react-icons/tb";
import { GiPayMoney, GiSkills, GiVibratingShield } from "react-icons/gi";

export const asideData = [
  { label: "Dashboard", href: "/dashboard", icon: <BiSolidDashboard /> },
  {
    label: "Portfolio",
    href: "/dashboard/portfolio",
    icon: <AiOutlineFundProjectionScreen />,
  },
  {
    label: "Testimonial",
    href: "/dashboard/testimonial",
    icon: <GiVibratingShield />,
  },
  { label: "Contact", href: "/dashboard/contact", icon: <BiSolidContact /> },
  { label: "Income", href: "/dashboard/income", icon: <TbMoneybag /> },
  { label: "Expense", href: "/dashboard/expense", icon: <GiPayMoney /> },
  {
    label: "IncomeState",
    href: "/dashboard/income_statement",
    icon: <TbReportMoney />,
  },
  { label: "Blog", href: "/dashboard/blog", icon: <FaBlog /> },
  { label: "Skill", href: "/dashboard/skill", icon: <GiSkills /> },
  { label: "Services", href: "/dashboard/service", icon: <FaServicestack /> },
  {
    label: "Experience",
    href: "/dashboard/experience",
    icon: <MdOutlineCastForEducation />,
  },
  {
    label: "Interview",
    href: "/dashboard/interview",
    icon: <MdOutlineCastForEducation />,
  },
  { label: "Setting", href: "/dashboard/setting", icon: <MdSettingsSuggest /> },
];
