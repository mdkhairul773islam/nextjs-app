"use client";
import Link from "next/link";
import { asideData } from "./asideData";
import { useSelector } from "react-redux";

const DashboardAside = () => {
  const pathname = useSelector((state) => state.dashboard.pathname);

  return (
    <div
      className={`h-screen w-[250px] fixed bg-teal-600 aside overflow-scroll`}
    >
      <div className="">
        <div className="sticky top-0 bg-teal-600 z-10 mb-5 border-b h-[64px] flex justify-center">
          <Link
            href="/dashboard"
            className="relative mx-auto [line-height:64px] font-mono font-bold z-[1] text-3xl text-white tracking-[4px]  uppercase"
          >
            <span className="absolute z-[-1] left-[50%] top-[50%] translate-x-[-50%] translate-y-[-50%] h-8 w-8 after:absolute after:content-[''] after:left-0 after:top-0  after:h-full after:w-full after:bg-teal-700 after:rounded-full after:z-[-1] before:absolute before:content-[''] before:h-full before:w-full before:left-0 before:top-0 before:bg-white before:rounded-full before:z-[-2] before:animate-ping"></span>
            <span>Mehedi</span>
          </Link>
        </div>
        {asideData?.map(({ href, label, icon }, i) => {
          return (
            <Link
              key={i}
              href={href}
              className={`relative z-[1] flex items-center [transition:.1s] gap-2 p-2 px-6 text-white  mb-2 font-mono uppercase  text-lg tracking-widest after:absolute after:content-[''] after:right-0 after:top-0 after:bottom-0 after:w-0 after:duration-500  after:rounded-s-full after:z-[-1] ${
                pathname == href
                  ? "after:bg-white !text-teal-600 after:w-[95%]"
                  : "after:bg-transparent text-white"
              }`}
            >
              {pathname == href && (
                <>
                  <span className="absolute right-[-4px] -top-[18px]  h-5 w-5 rounded-full bg-transparent  border-b-[3px] -rotate-45 border-b-white"></span>
                  <span className="absolute right-[-4px] -bottom-[18px]  h-5 w-5 rounded-full bg-transparent  border-t-[3px] rotate-45 border-t-white"></span>
                </>
              )}
              {icon}
              {label}
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default DashboardAside;
