"use client";

const DashboardBody = ({ children }) => {
  return (
    <div className="p-5 border shadow-[0px_0px_10px_rgba(0,0,0,0.04)] rounded-md">
      {children}
    </div>
  );
};

export default DashboardBody;
