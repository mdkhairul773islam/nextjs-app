import React, { useState } from "react";
import DashboardAside from "./DashboardAside/DashboardAside";
import DashboardHeader from "./DashboardHeader/DashboardHeader";

const DashboardLayout = ({ children }) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <>
      {isOpen && <DashboardAside />}
      <div className={`${isOpen ? "ml-[250px]" : ""}`}>
        <DashboardHeader setIsOpen={setIsOpen} isOpen={isOpen} />
        <div className="min-h-[calc(100vh-_68px)] mt-1 p-4 ">{children}</div>
      </div>
    </>
  );
};

export default DashboardLayout;
