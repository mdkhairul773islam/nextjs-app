"use client";
import Link from "next/link";
import { MdOutlineDarkMode } from "react-icons/md";
import { FaBars } from "react-icons/fa";
import Notification from "./Notification";
import FullScreen from "./FullScreen";
import { useDispatch, useSelector } from "react-redux";
import { FiSun } from "react-icons/fi";
import { toggleTheme } from "@/redux/features/themeSlice";

const DashboardHeader = ({ setIsOpen, isOpen }) => {
  const isDarkTheme = useSelector((state) => state.theme.isDarkTheme);
  const dispatch = useDispatch();

  return (
    <div
      className="sticky top-0 bg-white"
      style={{ boxShadow: "0 2px 5px rgba(0,0,0,0.3)" }}
    >
      <div className="px-4">
        <div className="flex items-center justify-between h-16">
          <div
            onClick={() => setIsOpen(!isOpen)}
            className="cursor-pointer text-teal-600 font-mono border-2 border-teal-600 h-8 w-8 rounded-md flex items-center justify-center text-xl font-bold"
          >
            <FaBars />
          </div>
          <div className="flex items-center gap-2 md:gap-4 lg:gap-10">
            <FullScreen />
            {isDarkTheme ? (
              <div
                className="text-2xl cursor-pointer"
                onClick={() => dispatch(toggleTheme())}
              >
                <FiSun />
              </div>
            ) : (
              <div
                className="text-2xl cursor-pointer"
                onClick={() => dispatch(toggleTheme())}
              >
                <MdOutlineDarkMode />
              </div>
            )}

            <Notification />
            <div>
              <Link
                href="/"
                className="hidden md:block p-2 px-3 border-none bg-teal-500 hover:bg-teal-600 text-white capitalize font-mono text-lg text-center"
              >
                View Website
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHeader;
