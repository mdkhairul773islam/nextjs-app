"use client";
import Link from "next/link";
import { useState } from "react";
import { MdNotifications } from "react-icons/md";
import { useGetContactsQuery } from "@/redux/features/contact/contactApi";

const Notification = () => {
  const { data: contacts, isLoading, isError } = useGetContactsQuery();
  const [dropdown, setDropdown] = useState(false);
  let filteredContact = [];

  let content = null;
  if (isLoading) content = <h1>Loading..</h1>;

  if (!isLoading && isError) content = <h1>Error</h1>;

  if (!isLoading && !isError && contacts?.length === 0)
    content = <h1>No Contacts Found!</h1>;

  if (!isLoading && !isError && contacts?.length > 0) {
    filteredContact = contacts.filter((item) => item.status == "false");
    content = (
      <div>
        {filteredContact?.map(({ id, name, description }) => (
          <Link
            href={`/dashboard/contact/${id}`}
            key={id}
            onClick={() => setDropdown(!dropdown)}
            className="py-2 px-4 border-b block hover:bg-gray-300"
          >
            <span className="block line-clamp-1 font-medium">{name}</span>
            <span className="block line-clamp-1">{description}</span>
          </Link>
        ))}
      </div>
    );
  }

  return (
    <div className="relative">
      <div
        className="text-2xl cursor-pointer relative"
        onClick={() => setDropdown(!dropdown)}
      >
        <MdNotifications />
        <span className="absolute -right-1 -top-1 h-4 w-4 text-xs rounded-full bg-red-700 text-white flex items-center justify-center">
          {isLoading ? 0 : filteredContact?.length}
        </span>
      </div>
      {dropdown && (
        <div className="absolute notification top-[47px] right-0 w-80 max-h-96 overflow-y-scroll bg-white shadow-xl rounded-sm border ">
          {content}
        </div>
      )}
    </div>
  );
};

export default Notification;
