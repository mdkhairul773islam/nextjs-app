"use client";
import { useEffect, useState } from "react";
import { AiOutlineExpand } from "react-icons/ai";

const FullScreen = () => {
  const [fullscreen, setFullscreen] = useState(false);

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const updateFullScreenState = () => {
      setFullscreen(Boolean(document.fullscreenElement));
    };

    updateFullScreenState();
    document.addEventListener("fullscreenchange", updateFullScreenState);

    return () => {
      document.removeEventListener("fullscreenchange", updateFullScreenState);
    };
  }, []);

  return (
    <div onClick={toggleFullScreen} className="cursor-pointer text-2xl">
      <AiOutlineExpand />
    </div>
  );
};

export default FullScreen;
