"use client";
import { useRouter } from "next/navigation";
import { GoTrash } from "react-icons/go";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteExpenseMutation } from "@/redux/features/expense/expenseApi";
import { useEffect } from "react";
import toastify from "@/utils/toastify";

const ExpenseTr = ({ expense, index }) => {
  const { id, name, amount, expense_date } = expense || {};

  const [deleteExpense, { isLoading, isSuccess, isError }] =
    useDeleteExpenseMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Portfolio Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteExpense(id);
  };

  return (
    <>
      <tr className=" even:bg-teal-50">
        <td className="p-2 w-[20px]">{index + 1}</td>
        <td className="p-2 w-[200px]">{name}</td>
        <td className="p-2 w-[220px]">{amount}</td>
        <td className="p-2">{expense_date}</td>
        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <div className="text-xl text-gray-700 cursor-pointer">
              <BsPencilSquare />
            </div>
          </div>
        </td>
      </tr>
    </>
  );
};

export default ExpenseTr;
