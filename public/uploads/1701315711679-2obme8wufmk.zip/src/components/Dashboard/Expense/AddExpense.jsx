"use client";
import axios from "axios";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { activeModal } from "@/redux/features/dashboard/dashboardSlice";
import { useDispatch } from "react-redux";

const AddExpense = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [inputs, setInputs] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newInputs = { ...inputs, amount: Number(inputs.amount) };
    axios
      .post("/api/expense", newInputs)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setIsLoading(false);
        setInputs({});
        dispatch(activeModal());
        router.refresh();
      });
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  return (
    <div className="border bg-white p-5 w-[600px] mx-auto">
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="flex flex-col  gap-6">
          <div className="flex flex-col gap-3">
            <div className="">
              <label htmlFor="name" className="inputLabel">
                Name
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="name"
                placeholder="Name"
                name="name"
                required
                className="inputField "
                value={inputs.name || ""}
                onChange={handleChange}
              />
            </div>

            <div className="">
              <label htmlFor="amount" className="inputLabel">
                Amount
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="amount"
                placeholder="Amount"
                name="amount"
                required
                className="inputField "
                value={inputs.amount || ""}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="expense_date" className="inputLabel">
                Expense Date
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="date"
                id="expense_date"
                name="expense_date"
                required
                className="inputField "
                value={inputs.expense_date || ""}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
            <div
              onClick={() => dispatch(activeModal())}
              className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
            >
              Cancel
            </div>
            <button
              disabled={isLoading ? true : false}
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
            >
              {isLoading ? "Loading..." : "Submit"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddExpense;
