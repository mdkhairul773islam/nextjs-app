"use client";
import ExpenseTr from "./ExpenseTr";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";
import TableSkeleton from "../ui/TableSkeleton";
import { useGetExpensesQuery } from "@/redux/features/expense/expenseApi";

const AllExpense = () => {
  const { data: expenses, isLoading, isError } = useGetExpensesQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && expenses?.length === 0)
    content = <TableEmpty message="No Expense Found!" />;

  if (!isLoading && !isError && expenses?.length > 0) {
    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Name</th>
              <th className="p-2">Amount</th>
              <th className="p-2">Expense Date</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {expenses?.map((expense, index) => {
              return (
                <ExpenseTr key={expense.id} expense={expense} index={index} />
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllExpense;
