"use client";
import axios from "axios";
import toastify from "@/utils/toastify";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import SkillImgUpload from "./SkillImgUpload";
import { activeModal } from "@/redux/features/dashboard/dashboardSlice";
import { useAddSkillMutation } from "@/redux/features/skill/skillApi";

const AddSkill = () => {
  const dispatch = useDispatch();
  const [file, setFile] = useState(null);
  const [inputs, setInputs] = useState({});
  const [addSkill, { isSuccess, isLoading, isError }] = useAddSkillMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Skill Added Successfully!");
      setInputs({});
      dispatch(activeModal());
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, dispatch, isError]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = new FormData();
    data.append("file", file);
    data.append("upload_preset", "uploads");

    try {
      const uploadRes = await axios.post(process.env.CLOUDINARY_API, data);

      const { url } = uploadRes.data;

      const newSkill = {
        ...inputs,
        image: url,
      };

      addSkill(newSkill);
    } catch (error) {
      toastify.error(error.message);
    }
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  return (
    <div className="border bg-white p-5 w-[80%] mx-auto">
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="grid lg:grid-cols-[30%_auto] gap-6">
          <SkillImgUpload file={file} setFile={setFile} />

          <div className="flex flex-col gap-3">
            <div className="">
              <label htmlFor="name" className="inputLabel">
                Skill Name
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="name"
                placeholder="Skill Name"
                name="name"
                required
                className="inputField "
                value={inputs.name || ""}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
            <div
              onClick={() => dispatch(activeModal())}
              className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
            >
              Cancel
            </div>
            <button
              disabled={isLoading ? true : false}
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
            >
              {isLoading ? "Loading..." : "Submit"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddSkill;
