"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteSkillMutation } from "@/redux/features/skill/skillApi";

const SkillTr = ({ skill, index }) => {
  const { id, name, image } = skill || {};

  const [deleteSkill, { isLoading, isError, isSuccess }] =
    useDeleteSkillMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Skill Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteSkill(id);
  };

  return (
    <tr className=" even:bg-teal-50 ">
      <td className="p-2 w-[20px]">{index + 1}</td>
      <td className="p-2 w-[20px]">
        <Image
          src={image}
          height={50}
          loading="lazy"
          width={50}
          alt={`${name} Image`}
          className="aspect-[3/2] bg-teal-100 w-full"
        />
      </td>
      <td className="p-2">{name}</td>

      <td className="p-2 w-[40px]">
        <div className="flex items-center justify-center gap-2">
          <Link
            href={`/dashboard/skill/${id}`}
            className="text-xl text-blue-600 cursor-pointer"
          >
            <FaRegEye />
          </Link>
          <div
            className="text-xl text-red-600 cursor-pointer"
            onClick={() => handleDelete(id)}
          >
            <GoTrash />
          </div>
          <Link
            href={`/dashboard/skill/edit/${id}`}
            className="text-xl text-gray-700 cursor-pointer"
          >
            <BsPencilSquare />
          </Link>
        </div>
      </td>
    </tr>
  );
};

export default SkillTr;
