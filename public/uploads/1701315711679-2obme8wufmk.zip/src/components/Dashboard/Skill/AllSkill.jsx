"use client";
import TableEmpty from "../ui/TableEmpty";
import TableError from "../ui/TableError";
import TableSkeleton from "../ui/TableSkeleton";
import SkillTr from "./SkillTr";
import { useGetSkillsQuery } from "@/redux/features/skill/skillApi";

const AllSkill = () => {
  const { data: skills, isLoading, isError } = useGetSkillsQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && skills?.length === 0)
    content = <TableEmpty message="No Skill Found!" />;

  if (!isLoading && !isError && skills?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full ">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Icon</th>
              <th className="p-2">Skill Name</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {skills?.map((skill, index) => (
              <SkillTr key={skill.id} skill={skill} index={index} />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllSkill;
