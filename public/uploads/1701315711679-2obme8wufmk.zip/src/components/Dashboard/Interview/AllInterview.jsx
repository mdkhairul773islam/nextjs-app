"use client";
import TableEmpty from "../ui/TableEmpty";
import InterviewTr from "./InterviewTr";
import TableError from "../ui/TableError";
import TableSkeleton from "../ui/TableSkeleton";
import { useGetInterviewsQuery } from "@/redux/features/interview/interviewApi";

const AllInterview = () => {
  const { data: interviews, isLoading, isError } = useGetInterviewsQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && interviews?.length === 0)
    content = <TableEmpty message="No Interview Question Found!" />;

  if (!isLoading && !isError && interviews?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Question En</th>
              <th className="p-2">Question Bn</th>
              <th className="p-2">Answer En</th>
              <th className="p-2">Answer Bn</th>
              <th className="p-2">Category</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {interviews?.map((interview, index) => (
              <InterviewTr
                key={interview.id}
                interview={interview}
                index={index}
              />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllInterview;
