"use client";
import Link from "next/link";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { truncateString } from "@/utils/helper";
import { useDeleteInterviewMutation } from "@/redux/features/interview/interviewApi";

const InterviewTr = ({ interview, index }) => {
  const { id, questionEn, questionBn, answerEn, answerBn, category } =
    interview || {};

  const [deleteInterview, { isLoading, isError, isSuccess }] =
    useDeleteInterviewMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Interview Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteInterview(id);
  };

  return (
    <>
      <tr className="even:bg-teal-50">
        <th className="p-2 w-[20px]">{index + 1}</th>
        <td className="p-2 w-[200px]">{truncateString(questionEn, 20)}</td>
        <td className="p-2 w-[200px]">
          {questionBn?.length > 0 ? truncateString(questionBn, 20) : "-"}
        </td>
        <td className="p-2 w-[200px]">{truncateString(answerEn, 20)}</td>
        <td className="p-2 w-[200px]">
          {answerBn?.length > 0 ? truncateString(answerBn, 20) : "-"}
        </td>
        <td className="p-2 w-[100px]">{category}</td>

        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <Link
              href={`/dashboard/interview/${id}`}
              className="text-xl text-blue-600 cursor-pointer"
            >
              <FaRegEye />
            </Link>
            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <Link
              href={`/dashboard/interview/edit/${id}`}
              className="text-xl text-gray-700 cursor-pointer"
            >
              <BsPencilSquare />
            </Link>
          </div>
        </td>
      </tr>
    </>
  );
};

export default InterviewTr;
