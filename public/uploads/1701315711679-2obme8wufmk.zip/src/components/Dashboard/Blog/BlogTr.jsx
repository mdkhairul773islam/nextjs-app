"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteBlogMutation } from "@/redux/features/blog/blogApi";
import { truncateString } from "@/utils/helper";

const BlogTr = ({ blog, index }) => {
  const { id, title, image, tags, description } = blog || {};

  const [deleteBlog, { isSuccess, isError, isLoading }] =
    useDeleteBlogMutation();

  useEffect(() => {
    if (isError) {
      toastify.error("There was an Error!");
    }

    if (isSuccess) {
      toastify.success("Blog Deleted Successfully");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteBlog(id);
  };

  return (
    <tr className="even:bg-teal-50 ">
      <td className="p-2 w-[20px]">{index + 1}</td>
      <td className="p-2 w-[20px]">
        <Image
          src={image}
          height={50}
          loading="lazy"
          width={50}
          alt={`${title} Image`}
          className="aspect-[3/2] bg-teal-100 w-full"
        />
      </td>
      <td className="p-2 w-[220px]">{truncateString(title, 20)}</td>

      <td className="p-2 w-[120px] flex flex-wrap">
        {tags?.map(({ value }, i) => (
          <span key={i}>{value},</span>
        ))}
      </td>
      <td className="p-2">{truncateString(description, 60)}</td>

      <td className="p-2 w-[40px]">
        <div className="flex items-center justify-center gap-2">
          <Link
            href={`/dashboard/blog/${id}`}
            className="text-xl text-blue-600 cursor-pointer"
          >
            <FaRegEye />
          </Link>
          <div
            className="text-xl text-red-600 cursor-pointer"
            onClick={() => handleDelete(id)}
          >
            <GoTrash />
          </div>
          <Link
            href={`/dashboard/blog/edit/${id}`}
            className="text-xl text-gray-700 cursor-pointer"
          >
            <BsPencilSquare />
          </Link>
        </div>
      </td>
    </tr>
  );
};

export default BlogTr;
