"use client";
import Image from "next/image";
import React, { useState } from "react";

const BlogImgUpload = ({ setFile }) => {
  const [image, setImage] = useState("/vercel.svg");

  return (
    <div>
      {image && (
        <Image
          height={50}
          width={50}
          src={image}
          className="aspect-square w-full bg-slate-200 border"
          alt="portfolio Image"
        />
      )}

      <input
        type="file"
        className="hidden"
        id="portfolioImg"
        onChange={(e) => {
          setFile(e.target.files?.[0]);
          setImage(URL.createObjectURL(e.target.files[0]));
        }}
      />
      <label
        htmlFor="portfolioImg"
        className="block bg-teal-600 text-center mt-2 text-white px-5 py-2"
      >
        Upload Photo
      </label>
    </div>
  );
};

export default BlogImgUpload;
