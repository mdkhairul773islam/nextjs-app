"use client";
import { useGetBlogsQuery } from "@/redux/features/blog/blogApi";
import BlogTr from "./BlogTr";
import TableSkeleton from "../ui/TableSkeleton";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";

const AllBlog = () => {
  const { data: blogs, isLoading, isError } = useGetBlogsQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && blogs?.length === 0)
    content = <TableEmpty message="No Blog Found!" />;

  if (!isLoading && !isError && blogs?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full ">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Photo</th>
              <th className="p-2">Title</th>
              <th className="p-2">Tags</th>
              <th className="p-2">Description</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {blogs.map((blog, index) => (
              <BlogTr key={blog.id} blog={blog} index={index} />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllBlog;
