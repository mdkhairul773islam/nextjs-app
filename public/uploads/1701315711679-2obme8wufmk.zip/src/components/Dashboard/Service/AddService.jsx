"use client";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { activeModal } from "@/redux/features/dashboard/dashboardSlice";
import { useAddServiceMutation } from "@/redux/features/service/serviceApi";
import toastify from "@/utils/toastify";

const AddService = () => {
  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({});

  const [addService, { isSuccess, isLoading, isError }] =
    useAddServiceMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Service Added Successfully!");
      setInputs({});
      dispatch(activeModal());
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, dispatch, isError]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    addService(inputs);
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  return (
    <div className="border bg-white p-5 w-[80%] lg:w-[500px] mx-auto">
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-3">
          <div className="">
            <label htmlFor="name" className="inputLabel">
              Service Name
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="name"
              placeholder="Service Name"
              name="name"
              required
              className="inputField "
              value={inputs.name || ""}
              onChange={handleChange}
            />
          </div>
          <div className="">
            <label htmlFor="description" className="inputLabel">
              Description
              <span className="text-red-600"> *</span>
            </label>
            <textarea
              type="text"
              id="description"
              placeholder="Description"
              name="description"
              required
              className="inputField "
              value={inputs.description || ""}
              onChange={handleChange}
            ></textarea>
          </div>
        </div>
        <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
          <div
            onClick={() => dispatch(activeModal())}
            className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
          >
            Cancel
          </div>
          <button
            disabled={isLoading ? true : false}
            type="submit"
            className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
          >
            {isLoading ? "Loading..." : "Submit"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddService;
