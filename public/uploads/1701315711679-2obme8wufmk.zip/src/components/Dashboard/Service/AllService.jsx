"use client";
import TableEmpty from "../ui/TableEmpty";
import TableError from "../ui/TableError";
import TableSkeleton from "../ui/TableSkeleton";
import ServiceTr from "./ServiceTr";
import { useGetServicesQuery } from "@/redux/features/service/serviceApi";

const AllService = () => {
  const { data: services, isLoading, isError } = useGetServicesQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && services?.length === 0)
    content = <TableEmpty message="No Service Found!" />;

  if (!isLoading && !isError && services?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Service Name</th>
              <th className="p-2">Description</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {services?.map((service, index) => (
              <ServiceTr key={service.id} service={service} index={index} />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllService;
