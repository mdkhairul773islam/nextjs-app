"use client";
import Link from "next/link";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteServiceMutation } from "@/redux/features/service/serviceApi";
import { truncateString } from "@/utils/helper";

const ServiceTr = ({ service, index }) => {
  const { id, name, description } = service || {};

  const [deleteService, { isLoading, isError, isSuccess }] =
    useDeleteServiceMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Service Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteService(id);
  };

  return (
    <>
      <tr className="even:bg-teal-50">
        <th className="p-2 w-[20px]">{index + 1}</th>
        <td className="p-2 w-[220px]">{truncateString(name, 20)}</td>
        <td className="p-2">{truncateString(description, 70)}</td>

        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <Link
              href={`/dashboard/service/${id}`}
              className="text-xl text-blue-600 cursor-pointer"
            >
              <FaRegEye />
            </Link>
            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <Link
              href={`/dashboard/service/edit/${id}`}
              className="text-xl text-gray-700 cursor-pointer"
            >
              <BsPencilSquare />
            </Link>
          </div>
        </td>
      </tr>
    </>
  );
};

export default ServiceTr;
