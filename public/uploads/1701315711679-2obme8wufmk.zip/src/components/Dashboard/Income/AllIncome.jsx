"use client";
import IncomeTr from "./IncomeTr";
import TableSkeleton from "../ui/TableSkeleton";
import { useGetIncomesQuery } from "@/redux/features/income/incomeApi";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";

const AllIncome = () => {
  const { data: earnings, isLoading, isError } = useGetIncomesQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && earnings?.length === 0)
    content = <TableEmpty message="No Income Found!" />;

  if (!isLoading && !isError && earnings?.length > 0) {
    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Name</th>
              <th className="p-2">Amount</th>
              <th className="p-2">Income Date</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {earnings?.map((income, index) => {
              return <IncomeTr key={income.id} income={income} index={index} />;
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllIncome;
