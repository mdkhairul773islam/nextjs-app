"use client";
import Modal from "@/components/Modal";
import { GoTrash } from "react-icons/go";
import UpdateIncome from "./UpdateIncome";
import { useDispatch } from "react-redux";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteIncomeMutation } from "@/redux/features/income/incomeApi";
import { activeModal } from "@/redux/features/dashboard/dashboardSlice";
import { useEffect } from "react";
import toastify from "@/utils/toastify";

const IncomeTr = ({ income, index }) => {
  const dispatch = useDispatch();
  const { id, name, amount, income_date } = income || {};
  const [deleteIncome, { isLoading, isSuccess, isError }] =
    useDeleteIncomeMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Income Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteIncome(id);
  };

  return (
    <>
      <tr className="even:bg-teal-50">
        <td className="p-2 w-[20px]">{index + 1}</td>
        <td className="p-2 w-[200px]">{name}</td>
        <td className="p-2 w-[220px]">{amount}</td>
        <td className="p-2">{income_date}</td>
        <td className="p-2 w-[40px]">
          <span className="flex items-center justify-center gap-2">
            <span
              className="block text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </span>
            <span
              className="block text-xl text-gray-700 cursor-pointer"
            >
              <BsPencilSquare />
            </span>
          </span>
        </td>
      </tr>

      {/* <Modal>
        <UpdateIncome />
      </Modal> */}
    </>
  );
};

export default IncomeTr;
