"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { truncateString } from "@/utils/helper";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteTestimonialMutation } from "@/redux/features/testimonial/testimonialApi";

const ContactTr = ({ testimonial, index }) => {
  const { id, name, image, designation, description } = testimonial || {};

  const [deleteTestimonial, { isLoading, isError, isSuccess }] =
    useDeleteTestimonialMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Testimonial Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  // Testimonial Delete
  const handleDelete = (id) => {
    deleteTestimonial(id);
  };

  return (
    <>
      <tr className="even:bg-teal-50 ">
        <td className="p-2 w-5">{index + 1}</td>
        <td className="p-2 w-5">
          <Image
            src={image}
            height={50}
            loading="lazy"
            width={50}
            alt={`${name} Image`}
            className="aspect-[3/2] bg-teal-100 w-full"
          />
        </td>
        <td className="p-2 w-[200px]">{truncateString(name, 20)}</td>
        <td className="p-2 w-[200px]">{truncateString(designation, 20)}</td>
        <td className="p-2">{truncateString(description, 50)}</td>
        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <Link
              href={`/dashboard/testimonial/${id}`}
              className="text-xl text-blue-600 cursor-pointer"
            >
              <FaRegEye />
            </Link>

            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <div className="text-xl text-gray-700 cursor-pointer">
              <BsPencilSquare />
            </div>
          </div>
        </td>
      </tr>
    </>
  );
};

export default ContactTr;
