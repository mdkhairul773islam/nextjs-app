"use client";
import axios from "axios";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import TestimonialImgUpload from "./TestimonialImgUpload";
import { activeModal } from "@/redux/features/dashboard/dashboardSlice";

const AddTestimonial = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({});
  const [file, setFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = new FormData();
    data.append("file", file);
    data.append("upload_preset", "uploads");

    try {
      setIsLoading(true);
      const uploadRes = await axios.post(process.env.CLOUDINARY_API, data);

      const { url } = uploadRes.data;

      const newTestimonial = {
        ...inputs,
        image: url,
      };

      axios
        .post("/api/testimonials", newTestimonial)
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        })
        .finally(() => {
          setIsLoading(false);
          setInputs({});
          dispatch(activeModal());
          router.refresh();
        });
    } catch (error) {
      console.log(error.message);
    }
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  return (
    <div className="border bg-white p-5 w-[80%] mx-auto">
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="grid lg:grid-cols-[30%_auto] gap-6">
          <TestimonialImgUpload file={file} setFile={setFile} />

          <div className="flex flex-col gap-3">
            <div className="">
              <label htmlFor="name" className="inputLabel">
                Name
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="name"
                placeholder="Name"
                name="name"
                required
                className="inputField "
                value={inputs.name || ""}
                onChange={handleChange}
              />
            </div>

            <div className="">
              <label htmlFor="designation" className="inputLabel">
                Designation
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="designation"
                placeholder="Designation"
                name="designation"
                required
                className="inputField "
                value={inputs.designation || ""}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="description" className="inputLabel">
                Description
                <span className="text-red-600"> *</span>
              </label>
              <textarea
                type="text"
                id="description"
                placeholder="Description"
                name="description"
                required
                className="inputField "
                value={inputs.description || ""}
                onChange={handleChange}
              ></textarea>
            </div>
          </div>

          <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
            <div
              onClick={() => dispatch(activeModal())}
              className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
            >
              Cancel
            </div>
            <button
              disabled={isLoading ? true : false}
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
            >
              {isLoading ? "Loading..." : "Submit"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddTestimonial;
