"use client";
import TableEmpty from "../ui/TableEmpty";
import TableError from "../ui/TableError";
import TableSkeleton from "../ui/TableSkeleton";
import TestimonialTr from "./TestimonialTr";
import { useGetTestimonialsQuery } from "@/redux/features/testimonial/testimonialApi";

const AllTestimonial = () => {
  const { data: testimonials, isLoading, isError } = useGetTestimonialsQuery();

  // decide what to render
  let content = null;

  if (isLoading) {
    content = <TableSkeleton />;
  }

  if (!isLoading && isError) {
    content = <TableError message="Something is Error!" />;
  }

  if (!isLoading && !isError && testimonials?.length === 0) {
    content = <TableEmpty message="No Testimonials Found!" />;
  }

  if (!isLoading && !isError && testimonials?.length > 0) {
    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Image</th>
              <th className="p-2">Name</th>
              <th className="p-2">Designation</th>
              <th className="p-2">Description</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {testimonials?.map((testimonial, index) => {
              return (
                <TestimonialTr
                  key={testimonial.id}
                  testimonial={testimonial}
                  index={index}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
  return content;
};

export default AllTestimonial;
