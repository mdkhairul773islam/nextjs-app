"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import {
  useDeleteContactMutation,
  useEditContactMutation,
} from "@/redux/features/contact/contactApi";
import { isObjectEmpty, truncateString } from "@/utils/helper";

const ContactTr = ({ contact, index }) => {
  const [inputs, setInputs] = useState({});
  const [isEdit, setIsEdit] = useState(false);
  const { id, name, email, description, status } = contact || {};

  const [deleteContact, { isError, isSuccess }] = useDeleteContactMutation();
  const [
    editContact,
    { isLoading: editLoading, isError: editError, isSuccess: editSuccess },
  ] = useEditContactMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Contact Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  useEffect(() => {
    if (editSuccess) {
      toastify.success("Contact Updated Successfully!");
      setIsEdit(false);
    }

    if (editError) {
      toastify.error("There was an error!");
    }
  }, [editSuccess, editError]);

  const handleDelete = (id) => {
    deleteContact(id);
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  useEffect(() => {
    if (Object.keys(inputs).length != 0) {
      editContact({ id, data: inputs });
    }
  }, [id, inputs, editContact]);

  return (
    <>
      <tr className="even:bg-teal-50">
        <td className="p-2 w-[20px]">{index + 1}</td>
        <td className="p-2 w-[180px]">{truncateString(name, 20)}</td>
        <td className="p-2 w-[180px]">{truncateString(email, 20)}</td>
        <td className="p-2">{truncateString(description, 40)}</td>
        <td className="p-2 w-20">
          {isEdit ? (
            <>
              {editLoading ? (
                "Loading.."
              ) : (
                <select
                  name="status"
                  value={inputs.status}
                  onChange={handleChange}
                  className="w-full text-xs bg-gray-300 p-1 rounded border-none outline-none"
                >
                  <option>Options</option>
                  <option value="false">Pending</option>
                  <option value="true">Received</option>
                </select>
              )}
            </>
          ) : (
            <>
              {status == "true" ? (
                <span className="block text-center p-1 text-xs bg-green-600/20 text-green-600 rounded">
                  Received
                </span>
              ) : (
                <span className="block text-center p-1 text-xs bg-orange-600/20 text-orange-600 rounded">
                  Pending
                </span>
              )}
            </>
          )}
        </td>
        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <Link
              href={`/dashboard/contact/${id}`}
              className="text-xl text-blue-600 cursor-pointer"
            >
              <FaRegEye />
            </Link>

            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <button
              onClick={() => setIsEdit(!isEdit)}
              className="text-xl text-gray-700 cursor-pointer"
            >
              <BsPencilSquare />
            </button>
          </div>
        </td>
      </tr>
    </>
  );
};

export default ContactTr;
