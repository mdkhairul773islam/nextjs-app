"use client";
import TableEmpty from "../ui/TableEmpty";
import TableError from "../ui/TableError";
import TableSkeleton from "../ui/TableSkeleton";
import ExperienceTr from "./ExperienceTr";
import { useGetExperiencesQuery } from "@/redux/features/experience/experienceApi";

const AllExperience = () => {
  const { data: experiences, isLoading, isError } = useGetExperiencesQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && experiences?.length === 0)
    content = <TableEmpty message="No Experience Found!" />;

  if (!isLoading && !isError && experiences?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Company Name</th>
              <th className="p-2">Designation</th>
              <th className="p-2">Period</th>
              <th className="p-2">Description</th>
              <th className="p-2 w-[40px] text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {experiences?.map((experience, index) => (
              <ExperienceTr
                key={experience.id}
                experience={experience}
                index={index}
              />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllExperience;
