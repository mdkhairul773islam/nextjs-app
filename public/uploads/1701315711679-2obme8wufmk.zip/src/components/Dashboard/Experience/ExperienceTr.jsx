"use client";
import Link from "next/link";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { BsPencilSquare } from "react-icons/bs";
import { useDeleteExperienceMutation } from "@/redux/features/experience/experienceApi";
import { truncateString } from "@/utils/helper";

const ExperienceTr = ({ experience, index }) => {
  const { id, company_name, designation, period_of_time, description } =
    experience || {};

  const [deleteExperience, { isLoading, isError, isSuccess }] =
    useDeleteExperienceMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Experience Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  const handleDelete = (id) => {
    deleteExperience(id);
  };

  return (
    <>
      <tr className="even:bg-teal-50">
        <td className="p-2 w-[20px]">{index + 1}</td>
        <td className="p-2 w-[160px]">{truncateString(company_name, 20)}</td>
        <td className="p-2 w-[220px]">{truncateString(designation, 20)}</td>
        <td className="p-2 w-[160px]">{truncateString(period_of_time, 20)}</td>
        <td className="p-2">{truncateString(description, 40)}</td>
        <td className="p-2 w-[40px]">
          <div className="flex items-center justify-center gap-2">
            <Link
              href={`/dashboard/experience/${id}`}
              className="text-xl text-blue-600 cursor-pointer"
            >
              <FaRegEye />
            </Link>
            <div
              className="text-xl text-red-600 cursor-pointer"
              onClick={() => handleDelete(id)}
            >
              <GoTrash />
            </div>
            <Link
              href={`/dashboard/experience/edit/${id}`}
              className="text-xl text-gray-700 cursor-pointer"
            >
              <BsPencilSquare />
            </Link>
          </div>
        </td>
      </tr>
    </>
  );
};

export default ExperienceTr;
