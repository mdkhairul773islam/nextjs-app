"use client";
import { useGetIncomesQuery } from "@/redux/features/income/incomeApi";
import TableSkeleton from "../ui/TableSkeleton";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";

const IncomeReport = () => {
  const { data: earnings, isLoading, isError } = useGetIncomesQuery();

  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && !isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && earnings?.length === 0)
    content = <TableEmpty message="No Income Found!" />;

  if (!isLoading && !isError && earnings?.length > 0) {
    const totalIncome = earnings?.reduce((accumulator, income) => {
      return accumulator + income.amount;
    }, 0);

    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-1 text-sm">SL</th>
              <th className="p-1 text-sm">Name</th>
              <th className="p-1 text-sm">Income Date</th>
              <th className="p-1 text-sm">Amount</th>
            </tr>
          </thead>
          <tbody>
            {earnings?.map(({ name, amount, income_date }, index) => {
              return (
                <tr className="even:bg-teal-50" key={index}>
                  <th className="text-sm p-2 w-[20px]">{index + 1}</th>
                  <td className="text-sm p-2">{name}</td>
                  <td className="text-sm p-2 w-[130px]">{income_date}</td>
                  <td className="text-sm p-2 w-[80px]">{amount}</td>
                </tr>
              );
            })}

            <tr>
              <td colSpan={3} className="text-sm p-2  font-bold">
                Total Income
              </td>
              <td className="text-sm p-2 w-[100px] font-bold">{totalIncome}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
  return content;
};

export default IncomeReport;
