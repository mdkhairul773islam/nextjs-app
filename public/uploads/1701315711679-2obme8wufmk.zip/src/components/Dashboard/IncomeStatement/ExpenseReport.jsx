"use client";
import { useGetExpensesQuery } from "@/redux/features/expense/expenseApi";
import TableSkeleton from "../ui/TableSkeleton";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";

const ExpenseReport = () => {
  const { data: expenses, isLoading, isError } = useGetExpensesQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && !isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && expenses?.length === 0)
    content = <TableEmpty message="No Expense Found!" />;

  if (!isLoading && !isError && expenses?.length > 0) {
    const totalExpense = expenses?.reduce((accumulator, expense) => {
      return accumulator + expense.amount;
    }, 0);

    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-1 text-sm">SL</th>
              <th className="p-1 text-sm">Name</th>
              <th className="p-1 text-sm">Expense Date</th>
              <th className="p-1 text-sm">Amount</th>
            </tr>
          </thead>
          <tbody>
            {expenses?.map(({ name, amount, expense_date }, index) => {
              return (
                <tr className="even:bg-teal-50" key={index}>
                  <th className="text-sm p-2 w-[20px]">{index + 1}</th>
                  <td className="text-sm p-2">{name}</td>
                  <td className="text-sm p-2 w-[130px]">{expense_date}</td>
                  <td className="text-sm p-2 w-[80px]">{amount}</td>
                </tr>
              );
            })}
            <tr className="">
              <td colSpan={3} className="text-sm p-2 font-bold">
                Total Expense
              </td>
              <td className="text-sm p-2 font-bold w-[100px]">
                {totalExpense}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default ExpenseReport;
