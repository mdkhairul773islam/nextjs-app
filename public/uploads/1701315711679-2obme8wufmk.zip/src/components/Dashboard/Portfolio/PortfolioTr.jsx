"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import toastify from "@/utils/toastify";
import { GoTrash } from "react-icons/go";
import { FaRegEye } from "react-icons/fa";
import { truncateString } from "@/utils/helper";
import { BsPencilSquare } from "react-icons/bs";
import { useDeletePortfolioMutation } from "@/redux/features/portfolio/portfolioApi";

const PortfolioTr = ({ project, index }) => {
  // Destructure Project
  const { id, title, image, github_link, live_link, tech, category } =
    project || {};

  const [deletePortfolio, { isLoading, isError, isSuccess }] =
    useDeletePortfolioMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Portfolio Deleted Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  // Portfolio Delete
  const handleDelete = (id) => {
    deletePortfolio(id);
  };

  return (
    <tr className=" even:bg-teal-50 ">
      <td className="p-2 w-[20px]">{index + 1}</td>
      <td className="p-2 w-[20px]">
        <Image
          src={image}
          height={50}
          loading="lazy"
          width={50}
          alt={`${title} Image`}
          className="aspect-[3/2] bg-teal-100 w-full"
        />
      </td>
      <td className="p-2 w-[170px]">{truncateString(title, 20)}</td>
      <td className="p-2 w-[170px] ">
        <Link
          href="/"
          target="_blank"
          className="!block line-clamp-1 text-teal-600 underline"
        >
          {truncateString(github_link, 20)}
        </Link>
      </td>
      <td className="p-2 w-[170px]">
        <Link
          href="/"
          target="_blank"
          className="!block line-clamp-1 text-teal-600 underline"
        >
          {truncateString(live_link, 20)}
        </Link>
      </td>

      <td className="p-2 w-[80px]">{category[0]?.value}</td>
      <td className="p-2 w-[40px]">
        <div className="flex items-center justify-center gap-2">
          <Link
            href={`/dashboard/portfolio/${id}`}
            className="text-xl text-teal-600 cursor-pointer"
            title="Show"
          >
            <FaRegEye />
          </Link>
          <button
            disabled={isLoading}
            className="text-xl text-red-600 cursor-pointer"
            onClick={() => handleDelete(id)}
            title="Delete"
          >
            <GoTrash />
          </button>
          <Link
            href={`/dashboard/portfolio/edit/${id}`}
            className="text-xl text-gray-700 cursor-pointer"
            title="Edit"
          >
            <BsPencilSquare />
          </Link>
        </div>
      </td>
    </tr>
  );
};

export default PortfolioTr;
