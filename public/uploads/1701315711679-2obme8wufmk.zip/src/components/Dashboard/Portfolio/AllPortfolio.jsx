"use client";
import PortfolioTr from "./PortfolioTr";
import TableError from "../ui/TableError";
import TableEmpty from "../ui/TableEmpty";
import TableSkeleton from "../ui/TableSkeleton";
import { useGetPortfoliosQuery } from "@/redux/features/portfolio/portfolioApi";

const AllPortfolio = () => {
  const { data: projects, isLoading, isError } = useGetPortfoliosQuery();

  // decide what to render
  let content = null;

  // If Portfolio Loading
  if (isLoading) {
    content = <TableSkeleton />;
  }

  // If Portfolio is Error
  if (!isLoading && isError) {
    content = <TableError message="Something is Error!" />;
  }

  // If Portfolio Is Empty
  if (!isLoading && !isError && projects?.length === 0) {
    content = <TableEmpty message="No Portfolio Found!" />;
  }

  // If Portfolio length bigger than 0
  if (!isLoading && !isError && projects?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Photo</th>
              <th className="p-2">Title</th>
              <th className="p-2">Github Link</th>
              <th className="p-2">Live Link</th>
              <th className="p-2">Categories</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {projects?.map((project, index) => (
              <PortfolioTr key={project.id} project={project} index={index} />
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return content;
};

export default AllPortfolio;
