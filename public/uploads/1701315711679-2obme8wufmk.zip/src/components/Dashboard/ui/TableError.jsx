"use client";
import { BiError } from "react-icons/bi";

const TableError = ({ message }) => {
  return (
    <div className="flex items-center justify-center flex-col gap-3 h-[250px] ">
      <BiError className="text-2xl" />
      <div className="text-red-700 text-2xl">{message}</div>
    </div>
  );
};

export default TableError;
