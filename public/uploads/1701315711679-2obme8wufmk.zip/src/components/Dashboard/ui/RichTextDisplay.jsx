import React from "react";

function RichTextDisplay({ htmlContent }) {
  return <div className="max-w-full prose" dangerouslySetInnerHTML={{ __html: htmlContent }} />;
}

export default RichTextDisplay;
