"use client";

const TableSkeleton = () => {
  return (
    <div className="flex flex-col gap-2 animate-pulse">
      <div className="h-10 bg-gray-300 rounded-sm"></div>
      <div className="h-10 bg-gray-300 rounded-sm"></div>
      <div className="h-10 bg-gray-300 rounded-sm"></div>
      <div className="h-10 bg-gray-300 rounded-sm"></div>
      <div className="h-10 bg-gray-300 rounded-sm"></div>
      <div className="h-10 bg-gray-300 rounded-sm"></div>
    </div>
  );
};

export default TableSkeleton;
