"use client";
import { IoSadOutline } from "react-icons/io5";

const TableEmpty = ({ message }) => {
  return (
    <div className="flex items-center justify-center flex-col gap-3 h-[250px] ">
      <IoSadOutline className="text-3xl" />
      <div className="text-red-700 text-2xl">{message}</div>
    </div>
  );
};

export default TableEmpty;
