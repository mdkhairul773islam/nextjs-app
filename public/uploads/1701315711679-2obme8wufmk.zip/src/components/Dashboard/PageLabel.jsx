"use client";
import { replaceUnderscores } from "@/utils/helper";
import Link from "next/link";

const PageLabel = ({ title, children }) => {
  return (
    <div className="flex items-center justify-between border-b border-dashed py-4 mb-6 ">
      <h3 className="text-2xl font-bold font-mono capitalize text-slate-800 tracking-widest">
        {replaceUnderscores(title)}
      </h3>

      <div className="flex gap-5 items-center">
        <div className="flex items-center justify-start gap-2">
          <Link href="/dashboard" className="bg-slate-200  px-2 rounded-sm ">
            Dashboard
          </Link>
          <span className="bg-slate-200  px-2">/</span>
          <Link
            href={`/dashboard/${title}`}
            className="bg-teal-600 text-white px-2 capitalize rounded-sm"
          >
            {title}
          </Link>
        </div>
        {children}
      </div>
    </div>
  );
};

export default PageLabel;
