// Production and Development url
export const URL =
  process.env.NODE_ENV === "production"
    ? process.env.NEXT_PUBLIC_API_URL
    : "http://localhost:3000/api";

// Fetch Data from api
export async function fetchData(api) {
  const res = await fetch(`${URL}${api}`, {
    cache: "no-store",
  });

  if (!res.ok) {
    throw new Error("Failed to fetch data");
  }

  return res.json();
}

// Replace Under Scores by Space
export function replaceUnderscores(inputString) {
  return inputString.replace(/_/g, " ");
}

// Check object empty or not
export function isObjectEmpty(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      return false;
    }
  }
  return true;
}

// String Shorter function
export const truncateString = (str, num) => {
  if (str.length <= num) {
    return str;
  }
  return str.slice(0, num) + "...";
};
