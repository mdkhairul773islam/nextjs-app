import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { name, description } = body;

    const newService = await prisma.service.create({
      data: {
        name,
        description,
      },
    });

    return NextResponse.json(newService);
  } catch (error) {
    return NextResponse.json(
      { message: "Service Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const service = await prisma.service.findMany();

    return NextResponse.json(service);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
