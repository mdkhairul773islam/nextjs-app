import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const service = await prisma.service.findUnique({
      where: {
        id,
      },
    });

    if (!service) {
      return NextResponse.json(
        { message: "Service not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(service);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { name, description } = body;
    const { id } = params;

    const updateService = await prisma.service.update({
      where: {
        id,
      },
      data: {
        name,
        description,
      },
    });

    if (!updateService) {
      return NextResponse.json(
        { message: "Service not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateService);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.service.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Service has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
