import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const experience = await prisma.experience.findUnique({
      where: {
        id,
      },
    });

    if (!experience) {
      return NextResponse.json(
        { message: "Experience not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(experience);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { company_name, designation, period_of_time, description } = body;
    const { id } = params;

    const updateExperience = await prisma.experience.update({
      where: {
        id,
      },
      data: {
        company_name,
        designation,
        period_of_time,
        description,
      },
    });

    if (!updateExperience) {
      return NextResponse.json(
        { message: "Experience not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateExperience);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.experience.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Experience has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
