import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { company_name, designation, period_of_time, description } = body;

    const newExperience = await prisma.experience.create({
      data: {
        company_name,
        designation,
        period_of_time,
        description,
      },
    });

    return NextResponse.json(newExperience);
  } catch (error) {
    return NextResponse.json(
      { message: "Experience Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const experience = await prisma.experience.findMany();

    return NextResponse.json(experience);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
