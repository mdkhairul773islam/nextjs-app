import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { name, amount, expense_date } = body;

    const newExpense = await prisma.expense.create({
      data: {
        name,
        amount,
        expense_date,
      },
    });

    return NextResponse.json(newExpense);
  } catch (error) {
    return NextResponse.json(
      { message: "Expense Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const expense = await prisma.expense.findMany();

    return NextResponse.json(expense);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
