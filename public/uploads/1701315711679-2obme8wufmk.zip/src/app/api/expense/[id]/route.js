import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const expense = await prisma.expense.findUnique({
      where: {
        id,
      },
    });

    if (!expense) {
      return NextResponse.json(
        { message: "Expense not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(expense);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { name, amount, expense_date } = body;
    const { id } = params;

    const updateExpense = await prisma.expense.update({
      where: {
        id,
      },
      data: {
        name,
        amount,
        expense_date,
      },
    });

    if (!updateExpense) {
      return NextResponse.json(
        { message: "Expense not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateExpense);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.expense.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Expense has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
