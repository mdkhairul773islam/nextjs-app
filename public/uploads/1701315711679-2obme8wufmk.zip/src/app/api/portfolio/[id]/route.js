import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const portfolio = await prisma.portfolio.findUnique({
      where: {
        id,
      },
    });

    if (!portfolio) {
      return NextResponse.json(
        { message: "Portfolio not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(portfolio);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const {
      title,
      github_link,
      live_link,
      tech,
      image,
      category,
      description,
    } = body;
    const { id } = params;

    const updatePortfolio = await prisma.portfolio.update({
      where: {
        id,
      },
      data: {
        title,
        github_link,
        live_link,
        tech,
        image,
        category,
        description,
      },
    });

    if (!updatePortfolio) {
      return NextResponse.json(
        { message: "Contact not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updatePortfolio);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.portfolio.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Cortfolio has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
