import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const blog = await prisma.blog.findUnique({
      where: {
        id,
      },
    });

    if (!blog) {
      return NextResponse.json(
        { message: "Blog not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(blog);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { title, tags, image, description } = body;
    const { id } = params;

    const updateBlog = await prisma.blog.update({
      where: {
        id,
      },
      data: {
        title,
        tags,
        image,
        description,
      },
    });

    if (!updateBlog) {
      return NextResponse.json(
        { message: "Blog not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateBlog);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.blog.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Blog has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
