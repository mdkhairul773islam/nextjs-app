import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { title, tags, image, description } = body;

    const newBlog = await prisma.blog.createMany({
      data: {
        title,
        tags,
        image,
        description,
      },
    });

    return NextResponse.json(newBlog);
  } catch (error) {
    return NextResponse.json(
      { message: "Contact Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const blog = await prisma.blog.findMany();

    return NextResponse.json(blog);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
