import { join } from "path";
import uniqid from "uniqid";
import { writeFile } from "fs/promises";
import { NextResponse } from "next/server";
import prisma from "../../../../prisma/index";

export const POST = async (req) => {
  try {
    const data = await req.formData();
    const image = data.get("image");
    const title = data.get("title");
    const description = data.get("description");

    if (!image) {
      return NextResponse.json({ success: false });
    }

    const bytes = await image.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const uniqId = uniqid();
    const uploadDir = join(process.cwd(), "public/post");
    const path = join(uploadDir, `${uniqId}-${image.name}`);
    await writeFile(path, buffer);

    const newPost = await prisma.post.createMany({
      data: {
        title,
        image: `/post/${uniqId}-${image.name}`,
        description,
      },
    });

    return NextResponse.json(newPost);
  } catch (error) {
    return NextResponse.json({ message: "Post Error", error }, { status: 500 });
  }
};

export const GET = async () => {
  try {
    const post = await prisma.post.findMany();

    return NextResponse.json(post);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
