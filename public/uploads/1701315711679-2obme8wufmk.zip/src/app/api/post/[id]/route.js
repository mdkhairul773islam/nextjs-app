import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";
import { join } from "path";
import uniqid from "uniqid";
import { unlink } from "fs/promises";
import { writeFile } from "fs/promises";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const post = await prisma.post.findUnique({
      where: {
        id,
      },
    });

    if (!post) {
      return NextResponse.json(
        { message: "Blog not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(post);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const { id } = params;
    const data = await request.formData();
    const updatedImage = data.get("updatedImage");
    const title = data.get("title");
    const description = data.get("description");

    let updatedPostData = {
      title,
      description,
    };

    // Find Post
    const post = await prisma.post.findUnique({
      where: {
        id,
      },
    });

    // If Image is there
    if (updatedImage) {
      console.log(updatedImage);
      // const uniqId = uniqid();
      // const bytes = await updatedImage.arrayBuffer();
      // const buffer = Buffer.from(bytes);

      // // Delete the old image file
      // const oldImagePath = join(process.cwd(), "public", post.image);
      // await unlink(oldImagePath);

      // // Write the new image file
      // const path = join(
      //   process.cwd(),
      //   "public/post",
      //   `${uniqId}-${updatedImage.name}`
      // );
      // await writeFile(path, buffer);

      // updatedPostData = {
      //   title,
      //   image: `/post/${uniqId}-${updatedImage.name}`,
      //   description,
      // };
    }

    const updatePost = await prisma.post.update({
      where: {
        id,
      },
      data: updatedPostData,
    });

    if (!updatePost) {
      return NextResponse.json({ message: "Post not found" }, { status: 404 });
    }

    return NextResponse.json(updatePost);
  } catch (error) {
    return NextResponse.json({ message: "Post Error", error }, { status: 500 });
  }
};
