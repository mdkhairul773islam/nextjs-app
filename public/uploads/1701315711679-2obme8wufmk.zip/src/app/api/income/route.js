import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { name, amount, income_date } = body;

    const newIncome = await prisma.income.create({
      data: {
        name,
        amount,
        income_date,
      },
    });

    return NextResponse.json(newIncome);
  } catch (error) {
    return NextResponse.json(
      { message: "Income Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const income = await prisma.income.findMany();

    return NextResponse.json(income);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
