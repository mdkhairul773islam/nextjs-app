import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const income = await prisma.income.findUnique({
      where: {
        id,
      },
    });

    if (!income) {
      return NextResponse.json(
        { message: "Income not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(income);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { name, amount, income_date } = body;
    const { id } = params;

    const updateIncome = await prisma.income.update({
      where: {
        id,
      },
      data: {
        name,
        amount,
        income_date,
      },
    });

    if (!updateIncome) {
      return NextResponse.json(
        { message: "Income not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateIncome);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.income.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Income has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
