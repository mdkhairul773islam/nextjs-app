import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const {
      site_name,
      mobile,
      email,
      resume_link,
      short_desc,
      long_desc,
      facebook_link,
      twitter_link,
      instagram_link,
      linkedin_link,
      github_link,
      address,
      copy_right,
      google_map,
      project_done,
      happy_client,
      award,
    } = body;

    const setting = await prisma.setting.create({
      data: {
        site_name,
        mobile,
        email,
        resume_link,
        short_desc,
        long_desc,
        facebook_link,
        twitter_link,
        instagram_link,
        linkedin_link,
        github_link,
        address,
        copy_right,
        google_map,
        project_done,
        happy_client,
        award,
      },
    });

    return NextResponse.json(setting);
  } catch (error) {
    return NextResponse.json(
      { message: "Setting Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const posts = await prisma.setting.findMany();

    return NextResponse.json(posts);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
