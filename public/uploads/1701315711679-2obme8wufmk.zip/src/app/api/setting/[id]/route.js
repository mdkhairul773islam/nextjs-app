import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const setting = await prisma.setting.findUnique({
      where: {
        id,
      },
    });

    if (!setting) {
      return NextResponse.json(
        { message: "Contact not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(setting);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const {
      site_name,
      mobile,
      email,
      resume_link,
      short_desc,
      long_desc,
      facebook_link,
      twitter_link,
      instagram_link,
      linkedin_link,
      github_link,
      address,
      copy_right,
      google_map,
      project_done,
      happy_client,
      award,
    } = body;
    const { id } = params;

    const updateSetting = await prisma.setting.update({
      where: {
        id,
      },
      data: {
        site_name,
        mobile,
        email,
        resume_link,
        short_desc,
        long_desc,
        facebook_link,
        twitter_link,
        instagram_link,
        linkedin_link,
        github_link,
        address,
        copy_right,
        google_map,
        project_done,
        happy_client,
        award,
      },
    });

    if (!updateSetting) {
      return NextResponse.json(
        { message: "Seting not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateSetting);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.setting.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Setting has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
