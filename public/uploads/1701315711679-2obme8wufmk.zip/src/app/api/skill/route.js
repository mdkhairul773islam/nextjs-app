import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { name, image } = body;

    const newSkill = await prisma.skill.createMany({
      data: {
        name,
        image,
      },
    });

    return NextResponse.json(newSkill);
  } catch (error) {
    return NextResponse.json(
      { message: "Skill Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const skill = await prisma.skill.findMany();

    return NextResponse.json(skill);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
