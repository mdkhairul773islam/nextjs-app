import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const skill = await prisma.skill.findUnique({
      where: {
        id,
      },
    });

    if (!skill) {
      return NextResponse.json(
        { message: "Skill not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(skill);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { name, image } = body;
    const { id } = params;

    const updateSkill = await prisma.skill.update({
      where: {
        id,
      },
      data: {
        name,
        image,
      },
    });

    if (!updateSkill) {
      return NextResponse.json(
        { message: "Skill not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateSkill);
  } catch (err) {
    return NextResponse.json(
      { message: "Skill update Error", err },
      { status: 500 }
    );
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.skill.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Skill has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
