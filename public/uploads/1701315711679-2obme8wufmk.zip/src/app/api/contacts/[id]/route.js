import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const contact = await prisma.contact.findUnique({
      where: {
        id,
      },
    });

    if (!contact) {
      return NextResponse.json(
        { message: "Contact not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(contact);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { status } = body;
    const { id } = params;

    const updateContact = await prisma.contact.update({
      where: {
        id,
      },
      data: {
        status,
      },
    });

    if (!updateContact) {
      return NextResponse.json(
        { message: "Contact not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateContact);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.contact.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Contact has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
