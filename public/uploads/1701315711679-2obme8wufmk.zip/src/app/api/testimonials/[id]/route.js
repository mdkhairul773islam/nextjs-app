import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const testimonial = await prisma.testimonial.findUnique({
      where: {
        id,
      },
    });

    if (!testimonial) {
      return NextResponse.json(
        { message: "Testimonial not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(testimonial);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { name, designation, image, description } = body;
    const { id } = params;

    const updateTestimonial = await prisma.testimonial.update({
      where: {
        id,
      },
      data: {
        name,
        designation,
        image,
        description,
      },
    });

    if (!updateTestimonial) {
      return NextResponse.json(
        { message: "Testimonial not found", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateTestimonial);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.testimonial.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Testimonial has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
