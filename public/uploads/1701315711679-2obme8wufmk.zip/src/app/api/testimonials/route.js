import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { name, designation, image, description } = body;

    const newTestimonial = await prisma.testimonial.create({
      data: {
        name,
        designation,
        image,
        description,
      },
    });

    return NextResponse.json(newTestimonial);
  } catch (error) {
    return NextResponse.json(
      { message: "Testimonial Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const posts = await prisma.testimonial.findMany();

    return NextResponse.json(posts);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
