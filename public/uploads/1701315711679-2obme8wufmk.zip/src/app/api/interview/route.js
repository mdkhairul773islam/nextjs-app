import prisma from "../../../../prisma/index";
import { NextResponse } from "next/server";

export const POST = async (req) => {
  try {
    const body = await req.json();
    const { questionEn, questionBn, answerEn, answerBn, category } = body;

    const newInterview = await prisma.interview.create({
      data: {
        questionEn,
        questionBn,
        answerEn,
        answerBn,
        category,
      },
    });

    return NextResponse.json(newInterview);
  } catch (error) {
    return NextResponse.json(
      { message: "Interview Error", error },
      { status: 500 }
    );
  }
};

export const GET = async () => {
  try {
    const interview = await prisma.interview.findMany();

    return NextResponse.json(interview);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};
