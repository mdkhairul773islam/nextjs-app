import prisma from "../../../../../prisma/index";
import { NextResponse } from "next/server";

export const GET = async (request, { params }) => {
  try {
    const { id } = params;

    const interview = await prisma.interview.findUnique({
      where: {
        id,
      },
    });

    if (!interview) {
      return NextResponse.json(
        { message: "Interview not found!", err },
        { status: 404 }
      );
    }

    return NextResponse.json(interview);
  } catch (err) {
    return NextResponse.json({ message: "GET Error", err }, { status: 500 });
  }
};

export const PATCH = async (request, { params }) => {
  try {
    const body = await request.json();
    const { questionEn, questionBn, answerEn, answerBn, category } = body;
    const { id } = params;

    const updateInterview = await prisma.interview.update({
      where: {
        id,
      },
      data: {
        questionEn,
        questionBn,
        answerEn,
        answerBn,
        category,
      },
    });

    if (!updateInterview) {
      return NextResponse.json(
        { message: "Interview not found!", err },
        { status: 404 }
      );
    }

    return NextResponse.json(updateInterview);
  } catch (err) {
    return NextResponse.json({ message: "update Error", err }, { status: 500 });
  }
};

export const DELETE = async (request, { params }) => {
  try {
    const { id } = params;

    await prisma.interview.delete({
      where: {
        id,
      },
    });

    return NextResponse.json("Interview has been deleted");
  } catch (err) {
    return NextResponse.json({ message: "DELETE Error", err }, { status: 500 });
  }
};
