"use client";
import "./globals.css";
import { store } from "@/redux/store";
import { Provider } from "react-redux";
import { Inter } from "next/font/google";
import ToastProvider from "@/components/Dashboard/ToastProvider";

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <title>Mehedi Portfolio</title>
        <meta
          name="description"
          content="I am a frontend web developer in Mymensingh, Bangladesh"
        />
      </head>
      <body className={`${inter.className} text-white`}>
        <Provider store={store}>
          <ToastProvider />
          {children}
        </Provider>
      </body>
    </html>
  );
}
