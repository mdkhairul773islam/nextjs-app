"use client";
import { useEffect } from "react";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import AllExpense from "@/components/Dashboard/Expense/AllExpense";
import AddExpense from "@/components/Dashboard/Expense/AddExpense";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { FiFolderPlus } from "react-icons/fi";

const Expense = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/expense"));
  }, [dispatch]);

  return (
    <div>
      <PageLabel title="expense">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Expense"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddExpense />
      </Modal>

      <DashboardBody>
        <AllExpense />
      </DashboardBody>
    </div>
  );
};

export default Expense;
