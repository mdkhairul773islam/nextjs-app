"use client";

const Error = () => {
  return <div className="text-red-600">Error</div>;
};

export default Error;
