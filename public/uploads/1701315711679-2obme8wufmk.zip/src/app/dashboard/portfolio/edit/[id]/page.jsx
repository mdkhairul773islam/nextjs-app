"use client";
import Link from "next/link";
import toastify from "@/utils/toastify";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  useEditPortfolioMutation,
  useGetPortfolioQuery,
} from "@/redux/features/portfolio/portfolioApi";
import CreatableSelect from "react-select/creatable";
import TableError from "@/components/Dashboard/ui/TableError";
import { useDispatch } from "react-redux";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const options = [
  { value: "reactjs", label: "React Js" },
  { value: "nextjs", label: "Next Js" },
  { value: "html5", label: "HTML 5" },
  { value: "css3", label: "CSS 3" },
  { value: "sass", label: "SASS" },
  { value: "bootstrap", label: "Bootstrap" },
  { value: "nodejs", label: "Node Js" },
  { value: "mongodb", label: "Mongodb" },
  { value: "express", label: "Express Js" },
];

const UpdatePortfolio = ({ params }) => {
  const [inputs, setInputs] = useState({});
  const router = useRouter();
  const dispatch = useDispatch();

  const {
    data: portfolio,
    isSuccess: portfolioGetSuccess,
    isLoading: portfolioLoading,
    isError: portfolioError,
  } = useGetPortfolioQuery(params.id);

  const [editPortfolio, { isSuccess, isLoading, isError }] =
    useEditPortfolioMutation();

  useEffect(() => {
    dispatch(changPath("/dashboard/portfolio"));
  }, [dispatch]);

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Portfolio Updated Successfully!");
      setInputs({});
      router.push("/dashboard/portfolio");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError, router]);

  useEffect(() => {
    if (portfolioGetSuccess) {
      setInputs(portfolio);
    }
  }, [portfolioGetSuccess, portfolio]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    editPortfolio({ id: params.id, data: inputs });
  };

  const handleSelectLang = (options) => {
    setInputs((prevState) => ({ ...prevState, tech: options }));
  };

  const handleSelectCat = (options) => {
    setInputs((prevState) => ({ ...prevState, category: [options] }));
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  let content = null;

  if (portfolioLoading) content = <TableSkeleton />;

  if (!portfolioLoading && portfolioError)
    content = <TableError message="Portfolio Update Error" />;

  if (!portfolioLoading && !portfolioError && portfolio) {
    const { tech, category } = portfolio || {};
    content = (
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-3">
          <div className="">
            <label htmlFor="title" className="inputLabel">
              Project Title
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="title"
              placeholder="Project Title"
              name="title"
              required
              className="inputField "
              value={inputs.title || ""}
              onChange={handleChange}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="github_link" className="inputLabel">
                Github Link
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="github_link"
                placeholder="Github Link"
                name="github_link"
                required
                className="inputField"
                value={inputs.github_link || ""}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="live_link" className="inputLabel">
                Live Link
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="live_link"
                placeholder="Live Link"
                name="live_link"
                required
                className="inputField"
                value={inputs.live_link || ""}
                onChange={handleChange}
              />
            </div>
          </div>

          <div>
            <label className="inputLabel">
              Languages
              <span className="text-red-600"> *</span>
            </label>
            <CreatableSelect
              options={options}
              defaultValue={tech}
              isMulti
              className="react-select-container "
              classNamePrefix="react-select"
              onChange={handleSelectLang}
            />
          </div>

          <div>
            <label className="inputLabel">
              Category
              <span className="text-red-600"> *</span>
            </label>
            <CreatableSelect
              options={[
                { value: "javascript", label: "Javascript" },
                { value: "htmlcss", label: "HTML/CSS" },
                { value: "react", label: "React JS" },
                { value: "mern", label: "MERN" },
                { value: "next", label: "NextJS" },
                { value: "bootstrap", label: "Bootstrap" },
                { value: "tailwind", label: "Tailwind CSS" },
              ]}
              defaultValue={category}
              className="react-select-container"
              classNamePrefix="react-select"
              onChange={handleSelectCat}
            />
          </div>

          <div>
            <label htmlFor="description" className="inputLabel">
              Description
              <span className="text-red-600"> *</span>
            </label>
            <textarea
              type="text"
              id="description"
              placeholder="Description"
              name="description"
              required
              className="inputField "
              value={inputs.description || ""}
              onChange={handleChange}
            ></textarea>
          </div>
        </div>

        <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
          <Link
            href="/dashboard/portfolio"
            className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
          >
            Cancel
          </Link>
          <button
            disabled={isLoading}
            type="submit"
            className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
          >
            {isLoading ? "Loading..." : "Update"}
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="">
      <PageLabel title="portfolio"></PageLabel>
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default UpdatePortfolio;
