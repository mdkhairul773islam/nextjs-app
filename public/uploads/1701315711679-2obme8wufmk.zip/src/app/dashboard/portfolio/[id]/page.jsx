"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { FiFolderPlus } from "react-icons/fi";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import { useGetPortfolioQuery } from "@/redux/features/portfolio/portfolioApi";
import AddPortfolio from "@/components/Dashboard/Portfolio/AddPortfolio";
import Modal from "@/components/Modal";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const ViewPortfolio = ({ params }) => {
  const {
    data: portfolio,
    isLoading,
    isError,
  } = useGetPortfolioQuery(params.id);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/portfolio"));
  }, [dispatch]);

  let content = null;
  if (isLoading) content = <TableSkeleton />;
  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;
  if (!isLoading && !isError && portfolio?.id)
    content = (
      <div className="grid lg:grid-cols-[40%_auto] gap-8">
        <Image
          src={portfolio?.image}
          height={720}
          width={1080}
          loading="lazy"
          className="w-full aspect-[3/2]  rounded-md object-contain"
          alt={portfolio?.title}
        />
        <div className="flex flex-col gap-3">
          <p>
            <span className="font-bold w-28 inline-block">Title:</span>
            {portfolio?.title}
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Github Link:</span>
            <Link
              href={portfolio?.github_link}
              target="_blank"
              className="text-blue-600"
            >
              {portfolio?.github_link}
            </Link>
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Live Link:</span>
            <Link
              href={portfolio?.live_link}
              target="_blank"
              className="text-blue-600"
            >
              {portfolio?.live_link}
            </Link>
          </p>

          <p className="flex items-start">
            <span className="font-bold w-28 inline-block">Technologies:</span>
            <div className="flex flex-wrap gap-1">
              {portfolio?.tech.map(({ value }, id) => (
                <span
                  key={id}
                  className="px-1 bg-teal-600/20 text-teal-600  rounded"
                >
                  {value}
                </span>
              ))}
            </div>
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Category:</span>
            {portfolio?.category.map(({ value }, id) => (
              <span key={id}>{value}</span>
            ))}
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Description:</span>
            {portfolio?.description}
          </p>
          <div>
            <Link
              href={"/dashboard/portfolio"}
              className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
            >
              Show All Portfolio
            </Link>
          </div>
        </div>
      </div>
    );

  return (
    <>
      <PageLabel title="portfolio">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Portfolio"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <DashboardBody>{content}</DashboardBody>

      <Modal>
        <AddPortfolio />
      </Modal>
    </>
  );
};

export default ViewPortfolio;
