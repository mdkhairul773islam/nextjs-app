"use client";
import { useEffect } from "react";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import AddPortfolio from "@/components/Dashboard/Portfolio/AddPortfolio";
import AllPortfolio from "@/components/Dashboard/Portfolio/AllPortfolio";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import { FiFolderPlus } from "react-icons/fi";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const Portfolio = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/portfolio"));
  }, [dispatch]);

  return (
    <>
      <PageLabel title="portfolio">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Portfolio"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddPortfolio />
      </Modal>

      <DashboardBody>
        <AllPortfolio />
      </DashboardBody>
    </>
  );
};

export default Portfolio;
