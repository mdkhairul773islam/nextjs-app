"use client";
import DashboardLayout from "@/components/Dashboard/DashboardLayout/DashboardLayout";

const layout = ({ children }) => {
  return (
    <div className="text-black">
      <DashboardLayout>{children}</DashboardLayout>
    </div>
  );
};

export default layout;
