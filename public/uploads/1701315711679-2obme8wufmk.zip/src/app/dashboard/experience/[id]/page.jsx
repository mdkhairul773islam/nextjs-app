"use client";
import Link from "next/link";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useGetExperienceQuery } from "@/redux/features/experience/experienceApi";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const ViewExperience = ({ params }) => {
  const {
    data: experience,
    isLoading,
    isError,
  } = useGetExperienceQuery(params.id);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/experience"));
  }, [dispatch]);

  let content = null;
  if (isLoading) content = <TableSkeleton />;
  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;
  if (!isLoading && !isError && experience?.id) {
    let desc = experience.description?.split("--");

    content = (
      <div className="flex flex-col gap-3">
        <p>
          <span className="font-bold w-[150px] inline-block ">
            Compnay Name:
          </span>
          {experience?.company_name}
        </p>
        <p>
          <span className="font-bold w-[150px] inline-block ">
            Designation:
          </span>
          {experience?.designation}
        </p>
        <p>
          <span className="font-bold w-[150px] inline-block ">
            Period of Time:
          </span>
          {experience?.period_of_time}
        </p>
        <p>
          <span className="font-bold w-[150px] inline-block ">
            Description:
          </span>
          {desc?.slice(1, desc?.length)?.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </p>

        <div>
          <Link
            href={"/dashboard/experience"}
            className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
          >
            Show All Experience
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageLabel title="experience" />
      <DashboardBody>{content}</DashboardBody>
    </>
  );
};

export default ViewExperience;
