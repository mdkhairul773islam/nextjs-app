"use client";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { FiFolderPlus } from "react-icons/fi";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import Link from "next/link";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import TableEmpty from "@/components/Dashboard/ui/TableEmpty";
import Image from "next/image";
import { FaRegEye } from "react-icons/fa";
import { GoTrash } from "react-icons/go";
import { BsPencilSquare } from "react-icons/bs";
import { useGetPostsQuery } from "@/redux/features/post/postApi";
import { truncateString } from "@/utils/helper";

const Post = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/post"));
  }, [dispatch]);

  const { data: posts, isLoading, isError } = useGetPostsQuery();

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && posts?.length === 0)
    content = <TableEmpty message="No Post Found!" />;

  if (!isLoading && !isError && posts?.length > 0) {
    content = (
      <div className="overflow-x-auto">
        <table className="w-full ">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Photo</th>
              <th className="p-2">Title</th>
              <th className="p-2">Description</th>
              <th className="p-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="">
            {posts.map((post, index) => {
              const { id, image, title, description } = post || {};
              return (
                <tr key={index} className="even:bg-teal-50 ">
                  <td className="p-2 w-[20px]">{index + 1}</td>
                  <td className="p-2 w-[20px]">
                    <Image
                      src={image}
                      height={50}
                      loading="lazy"
                      width={50}
                      alt={`${title} Image`}
                      className="aspect-[3/2] bg-teal-100 w-full"
                    />
                  </td>
                  <td className="p-2 w-[220px]">{truncateString(title, 20)}</td>

                  <td className="p-2">{truncateString(description, 60)}</td>

                  <td className="p-2 w-[40px]">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        href={`/dashboard/post/${id}`}
                        className="text-xl text-blue-600 cursor-pointer"
                      >
                        <FaRegEye />
                      </Link>
                      <div className="text-xl text-red-600 cursor-pointer">
                        <GoTrash />
                      </div>
                      <Link
                        href={`/dashboard/post/edit/${id}`}
                        className="text-xl text-gray-700 cursor-pointer"
                      >
                        <BsPencilSquare />
                      </Link>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div>
      <PageLabel title="post">
        <Link
          href="/dashboard/post/create"
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Post"
        >
          <FiFolderPlus />
        </Link>
      </PageLabel>

      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default Post;
