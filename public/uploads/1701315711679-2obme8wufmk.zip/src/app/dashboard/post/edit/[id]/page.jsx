"use client";
import { useEffect, useState } from "react";
import toastify from "@/utils/toastify";
import { useRouter } from "next/navigation";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  useEditPostMutation,
  useGetPostQuery,
} from "@/redux/features/post/postApi";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useDispatch } from "react-redux";
import Link from "next/link";
import Image from "next/image";
import { BiSolidCloudUpload } from "react-icons/bi";

const UpdatePost = ({ params }) => {
  const [inputs, setInputs] = useState({});
  const [file, setFile] = useState(null);
  const router = useRouter();
  const dispatch = useDispatch();

  const {
    data: post,
    isSuccess: postSuccess,
    isLoading: postLoading,
    isError: postError,
  } = useGetPostQuery(params.id);
  const [editPost, { isSuccess, isLoading, isError }] = useEditPostMutation();

  // Initial Render changepath
  useEffect(() => {
    dispatch(changPath("/dashboard/post"));
  }, [dispatch]);

  // After Edit use Effect
  useEffect(() => {
    if (isSuccess) {
      toastify.success("Post Updated Successfully!");
      router.push("/dashboard/post");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError, router]);

  // Post Update use Effect
  useEffect(() => {
    if (postSuccess) {
      setInputs(post);
    }
  }, [postSuccess, post, setInputs]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();

    try {
      for (const key in inputs) {
        if (inputs.hasOwnProperty(key)) {
          formData.set(key, inputs[key]);
        }
      }
      formData.set("updatedImage", file);

      editPost({ id: params.id, data: formData });
    } catch (error) {
      toastify.error(error.message);
    }
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  // Decide what to render
  let content = null;
  if (postLoading) content = <TableSkeleton />;
  if (!postLoading && postError)
    content = <TableError message="Post Get Error" />;

  if (!postLoading && !postError && post) {
    content = (
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="grid lg:grid-cols-[30%_auto] gap-6">
          <div>
            <input
              type="file"
              name="file"
              id="file"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0])}
            />
            <label
              htmlFor="file"
              className="h-[300px] w-full bg-gray-200  cursor-pointer flex items-center justify-center"
            >
              {file || inputs.image ? (
                <Image
                  className="h-full w-full object-contain border-2"
                  alt=""
                  src={file ? URL.createObjectURL(file) : inputs.image}
                  height={400}
                  width={400}
                />
              ) : (
                <h3 className="inline-flex items-center gap-2 text-2xl">
                  <BiSolidCloudUpload /> Select Image
                </h3>
              )}
            </label>
          </div>

          <div className="flex flex-col gap-3">
            <div className="">
              <label htmlFor="title" className="inputLabel">
                Post Title
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="title"
                placeholder="Post Title"
                name="title"
                required
                className="inputField"
                value={inputs.title || ""}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="description" className="inputLabel">
                Description
                <span className="text-red-600"> *</span>
              </label>

              <textarea
                type="text"
                id="description"
                placeholder="Post Title"
                name="description"
                required
                className="inputField"
                value={inputs.description || ""}
                onChange={handleChange}
              ></textarea>
            </div>
          </div>

          <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
            <Link
              href="/dashboard/post"
              className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
            >
              Cancel
            </Link>
            <button
              disabled={isLoading ? true : false}
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
            >
              {isLoading ? "Loading..." : "Submit"}
            </button>
          </div>
        </div>
      </form>
    );
  }

  return (
    <div className="">
      <PageLabel title="post"></PageLabel>
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default UpdatePost;
