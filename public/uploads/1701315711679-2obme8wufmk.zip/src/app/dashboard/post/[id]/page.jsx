"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import TableError from "@/components/Dashboard/ui/TableError";
import { useGetPostQuery } from "@/redux/features/post/postApi";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const ViewPost = ({ params }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/post"));
  }, [dispatch]);

  const { data: post, isLoading, isError } = useGetPostQuery(params.id);

  let content = null;
  if (isLoading) content = <TableSkeleton />;
  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;
  if (!isLoading && !isError && post?.id)
    content = (
      <div className="grid grid-cols-1 gap-8">
        <Image
          src={post?.image}
          height={300}
          width={300}
          loading="lazy"
          className="w-full h-auto border border-teal-600 rounded-md object-cover"
          alt={post?.title}
        ></Image>
        <div className="flex flex-col gap-3">
          <p className="flex">
            <span className="font-bold w-28 inline-block">Title:</span>
            {post?.title}
          </p>

          <p>
            <span className="font-bold w-28 inline-block">Description:</span>
            {post?.description}
            {/* <div
              className="prose  w-full max-w-full prose-img:rounded-xl prose-headings:underline prose-a:text-blue-600"
              dangerouslySetInnerHTML={{ __html: post?.description }}
            /> */}
          </p>
          <div>
            <Link
              href={"/dashboard/post"}
              className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
            >
              Show All Post
            </Link>
          </div>
        </div>
      </div>
    );

  return (
    <div>
      <PageLabel title="post" />
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default ViewPost;
