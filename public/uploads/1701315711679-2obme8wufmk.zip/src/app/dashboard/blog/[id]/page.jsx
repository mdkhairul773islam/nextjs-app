"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import TableError from "@/components/Dashboard/ui/TableError";
import { useGetBlogQuery } from "@/redux/features/blog/blogApi";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const ViewBlog = ({ params }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/blog"));
  }, [dispatch]);

  const { data: blog, isLoading, isError } = useGetBlogQuery(params.id);

  let content = null;
  if (isLoading) content = <TableSkeleton />;
  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;
  if (!isLoading && !isError && blog?.id)
    content = (
      <div className="grid grid-cols-1 gap-8">
        <Image
          src={blog?.image}
          height={300}
          width={300}
          loading="lazy"
          className="w-full h-auto border border-teal-600 rounded-md object-cover"
          alt={blog?.title}
        ></Image>
        <div className="flex flex-col gap-3">
          <p className="flex">
            <span className="font-bold w-28 inline-block">Title:</span>
            {blog?.title}
          </p>

          <p className="flex">
            <span className="font-bold w-28 inline-block">Tags:</span>
            <div className="flex flex-wrap gap-1">
              {blog?.tags?.map(({ value }, id) => (
                <span
                  key={id}
                  className="px-1 bg-teal-600/20 text-teal-600  rounded"
                >
                  {value}
                </span>
              ))}
            </div>
          </p>

          <p>
            <span className="font-bold w-28 inline-block">Description:</span>
            {/* {blog?.description} */}
            <div
              className="prose  w-full max-w-full prose-img:rounded-xl prose-headings:underline prose-a:text-blue-600"
              dangerouslySetInnerHTML={{ __html: blog?.description }}
            />
          </p>
          <div>
            <Link
              href={"/dashboard/blog"}
              className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
            >
              Show All Blog
            </Link>
          </div>
        </div>
      </div>
    );

  return (
    <div>
      <PageLabel title="blog" />
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default ViewBlog;
