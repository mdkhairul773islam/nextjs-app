"use client";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import AllService from "@/components/Dashboard/Service/AllService";
import AddService from "@/components/Dashboard/Service/AddService";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { FiFolderPlus } from "react-icons/fi";

const Service = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/service"));
  }, [dispatch]);

  return (
    <>
      <PageLabel title="service">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Service"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddService />
      </Modal>

      <DashboardBody>
        <AllService />
      </DashboardBody>
    </>
  );
};

export default Service;
