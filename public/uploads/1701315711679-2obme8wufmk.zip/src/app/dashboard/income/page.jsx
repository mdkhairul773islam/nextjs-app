"use client";
import { useEffect } from "react";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import AllIncome from "@/components/Dashboard/Income/AllIncome";
import AddIncome from "@/components/Dashboard/Income/AddIncome";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { FiFolderPlus } from "react-icons/fi";

const Income = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/income"));
  }, [dispatch]);

  return (
    <div>
      <PageLabel title="income">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Income"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddIncome />
      </Modal>
      <DashboardBody>
        <AllIncome />
      </DashboardBody>
    </div>
  );
};

export default Income;
