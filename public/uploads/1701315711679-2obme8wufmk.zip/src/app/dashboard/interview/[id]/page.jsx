"use client";
import Link from "next/link";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import TableError from "@/components/Dashboard/ui/TableError";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { useGetInterviewQuery } from "@/redux/features/interview/interviewApi";
import RichTextDisplay from "@/components/Dashboard/ui/RichTextDisplay";

const ViewInterview = ({ params }) => {
  const {
    data: interview,
    isLoading,
    isError,
  } = useGetInterviewQuery(params.id);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/interview"));
  }, [dispatch]);

  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && interview?.id) {
    content = (
      <div className="flex flex-col gap-3">
        <p>
          <span className="font-bold w-52 inline-block">
            Question (In English):
          </span>
          {interview?.questionEn}
        </p>
        <p>
          <span className="font-bold w-52 inline-block">
            Question (In Bangla):
          </span>
          {interview?.questionBn}
        </p>
        <p>
          <span className="font-bold w-52 inline-block">
            Answer (In English):
          </span>
          <RichTextDisplay htmlContent={interview?.answerEn} />
        </p>
        <p>
          <span className="font-bold w-52 inline-block">
            Answer (In Bangla):
          </span>
          {interview?.answerBn}
        </p>

        <div>
          <Link
            href={"/dashboard/interview"}
            className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
          >
            Show All Interview
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageLabel title="interview" />
      <DashboardBody>{content}</DashboardBody>
    </>
  );
};

export default ViewInterview;
