"use client";
import { useEffect } from "react";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import { FiFolderPlus } from "react-icons/fi";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import AddInterview from "@/components/Dashboard/Interview/AddInterview";
import AllInterview from "@/components/Dashboard/Interview/AllInterview";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const Interview = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/interview"));
  }, [dispatch]);

  return (
    <>
      <PageLabel title="interview">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Interview"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddInterview />
      </Modal>

      <DashboardBody>
        <AllInterview />
      </DashboardBody>
    </>
  );
};

export default Interview;
