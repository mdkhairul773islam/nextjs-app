"use client";
import {
  useEditInterviewMutation,
  useGetInterviewQuery,
} from "@/redux/features/interview/interviewApi";
import Link from "next/link";
import dynamic from "next/dynamic";
const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });
import "react-quill/dist/quill.snow.css";
import toastify from "@/utils/toastify";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import PageLabel from "@/components/Dashboard/PageLabel";
import TableError from "@/components/Dashboard/ui/TableError";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const UpdateInterview = ({ params }) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({});
  const [answerValue, setAnswerValue] = useState("");

  useEffect(() => {
    dispatch(changPath("/dashboard/interview"));
  }, [dispatch]);

  const {
    data: interview,
    isSuccess: interviewGetSuccess,
    isLoading: interviewLoading,
    isError: interviewError,
  } = useGetInterviewQuery(params.id);

  const [editInterview, { isSuccess, isLoading, isError }] =
    useEditInterviewMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Interview Updated Successfully!");
      setAnswerValue("");
      setInputs({});
      router.push("/dashboard/interview");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError, router]);

  useEffect(() => {
    if (interviewGetSuccess) {
      const { answerEn, ...others } = interview || {};
      setAnswerValue(answerEn);
      setInputs(others);
    }
  }, [interviewGetSuccess, interview]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    editInterview({ id: params.id, data: inputs });
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  let content = null;

  if (interviewLoading) content = <TableSkeleton />;

  if (!interviewLoading && interviewError)
    content = <TableError message="Interview Error" />;

  if (!interviewLoading && !interviewError && interview) {
    content = (
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="">
              <label htmlFor="questionEn" className="inputLabel">
                Question (In English)
                <span className="text-red-600"> *</span>
              </label>
              <input
                type="text"
                id="questionEn"
                placeholder="Question (in English)"
                name="questionEn"
                required
                className="inputField "
                value={inputs.questionEn || ""}
                onChange={handleChange}
              />
            </div>
            <div className="">
              <label htmlFor="questionBn" className="inputLabel">
                Question (In Bangla)
              </label>
              <input
                type="text"
                id="questionBn"
                placeholder="Question (in Bangla)"
                name="questionBn"
                className="inputField "
                value={inputs.questionBn || ""}
                onChange={handleChange}
              />
            </div>
          </div>
          <div className="">
            <label htmlFor="category" className="inputLabel">
              Category
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="category"
              placeholder="Category"
              name="category"
              required
              className="inputField "
              value={inputs.category || ""}
              onChange={handleChange}
            />
          </div>
          <div className="">
            <label htmlFor="answerEn" className="inputLabel">
              Answer (In English)
              <span className="text-red-600"> *</span>
            </label>
            {/* <textarea
              type="text"
              id="answerEn"
              placeholder="Answer (In English)"
              name="answerEn"
              required
              className="inputField "
              value={inputs.answerEn || ""}
              onChange={handleChange}
            ></textarea> */}

            <ReactQuill
              theme="snow"
              value={answerValue}
              onChange={setAnswerValue}
            />
          </div>
          <div className="">
            <label htmlFor="answerBn" className="inputLabel">
              Answer (In Bangla)
            </label>
            <textarea
              type="text"
              id="answerBn"
              placeholder="Answer (In Bangla)"
              name="answerBn"
              className="inputField "
              value={inputs.answerBn || ""}
              onChange={handleChange}
            ></textarea>
          </div>
        </div>
        <div className="flex items-center gap-2 justify-end col-start-1 col-end-3">
          <Link
            href="/dashboard/interview"
            className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
          >
            Cancel
          </Link>
          <button
            disabled={isLoading ? true : false}
            type="submit"
            className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
          >
            {isLoading ? "Loading..." : "Update"}
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="">
      <PageLabel title="interview"></PageLabel>
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default UpdateInterview;
