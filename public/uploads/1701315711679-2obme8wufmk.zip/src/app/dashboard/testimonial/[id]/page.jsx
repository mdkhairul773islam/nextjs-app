"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useGetTestimonialQuery } from "@/redux/features/testimonial/testimonialApi";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";

const ViewTestimonial = ({ params }) => {
  const {
    data: testimonial,
    isLoading,
    isError,
  } = useGetTestimonialQuery(params.id);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/testimonial"));
  }, [dispatch]);

  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;

  if (!isLoading && !isError && testimonial?.id)
    content = (
      <div className="grid lg:grid-cols-[40%_auto] gap-8">
        <Image
          src={testimonial?.image}
          height={300}
          width={300}
          loading="lazy"
          className="w-full aspect-video border border-teal-600 rounded-md object-contain"
          alt={testimonial?.name}
        ></Image>
        <div className="flex flex-col gap-3">
          <p>
            <span className="font-bold w-28 inline-block">Name:</span>
            {testimonial?.name}
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Designation:</span>
            {testimonial?.designation}
          </p>
          <p>
            <span className="font-bold w-28 inline-block">Description:</span>
            {testimonial?.description}
          </p>
          <div>
            <Link
              href={"/dashboard/testimonial"}
              className="inline-flex p-2 px-5 bg-teal-600 text-white rounded-sm duration-300 hover:bg-teal-700"
            >
              Show All Testimonial
            </Link>
          </div>
        </div>
      </div>
    );
  return (
    <>
      <PageLabel title="testimonial" />
      <DashboardBody>{content}</DashboardBody>
    </>
  );
};

export default ViewTestimonial;
