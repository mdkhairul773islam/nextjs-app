"use client";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import AllTestimonial from "@/components/Dashboard/Testimonial/AllTestimonial";
import AddTestimonial from "@/components/Dashboard/Testimonial/AddTestimonial";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { FiFolderPlus } from "react-icons/fi";

const Testimonial = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/testimonial"));
  }, [dispatch]);

  return (
    <>
      <PageLabel title="testimonial">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Testimonial"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddTestimonial />
      </Modal>

      <DashboardBody>
        <AllTestimonial />
      </DashboardBody>
    </>
  );
};

export default Testimonial;
