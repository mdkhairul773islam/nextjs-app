"use client";
import toastify from "@/utils/toastify";
import { useEffect, useState } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  useEditSettingMutation,
  useGetSettingQuery,
} from "@/redux/features/setting/settingApi";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useDispatch } from "react-redux";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const DashboardSetting = () => {
  const dispatch = useDispatch();
  const ID = "65116eb16f3bb8a71a3379ee";
  const [inputs, setInputs] = useState({});
  const {
    data: setting,
    isSuccess: settingSuccess,
    isLoading: settingLoading,
    isError: settingError,
  } = useGetSettingQuery(ID);
  const [editSetting, { isSuccess, isLoading, isError }] =
    useEditSettingMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Setting Updated Successfully!");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError]);

  useEffect(() => {
    if (settingSuccess) {
      setInputs(setting);
    }
  }, [settingSuccess, setting]);

  useEffect(() => {
    dispatch(changPath("/dashboard/setting"));
  }, [dispatch]);

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    editSetting({ id: ID, data: inputs });
  };

  let content = null;
  if (settingLoading) content = <TableSkeleton />;
  if (!settingLoading && settingError)
    content = <TableError message="Setting Error" />;
  if (!settingLoading && !settingError && setting)
    content = (
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <label htmlFor="site_name" className="inputLabel text-slate-800">
              Site Name
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="site_name"
              placeholder="Blog Title"
              name="site_name"
              required
              className="inputField "
              value={inputs.site_name || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="mobile" className="inputLabel text-slate-800">
              Mobile
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="number"
              id="mobile"
              placeholder="Mobile"
              name="mobile"
              required
              className="inputField "
              value={inputs.mobile || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="email" className="inputLabel text-slate-800">
              Email
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="email"
              id="email"
              placeholder="Email"
              name="email"
              required
              className="inputField "
              value={inputs.email || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="resume_link" className="inputLabel text-slate-800">
              Resume Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="resume_link"
              placeholder="Resume Link"
              name="resume_link"
              required
              className="inputField "
              value={inputs.resume_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="twitter_link" className="inputLabel text-slate-800">
              Twitter Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="twitter_link"
              placeholder="Twitter Link"
              name="twitter_link"
              required
              className="inputField "
              value={inputs.twitter_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label
              htmlFor="facebook_link"
              className="inputLabel text-slate-800"
            >
              Facebook Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="facebook_link"
              placeholder="Facebook Link"
              name="facebook_link"
              required
              className="inputField "
              value={inputs.facebook_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label
              htmlFor="instagram_link"
              className="inputLabel text-slate-800"
            >
              Instagram Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="instagram_link"
              placeholder="Instagram Link"
              name="instagram_link"
              required
              className="inputField "
              value={inputs.instagram_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label
              htmlFor="linkedin_link"
              className="inputLabel text-slate-800"
            >
              Linkedin Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="linkedin_link"
              placeholder="Linkedin Link"
              name="linkedin_link"
              required
              className="inputField "
              value={inputs.linkedin_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="github_link" className="inputLabel text-slate-800">
              Github Link
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="github_link"
              placeholder="Github Link"
              name="github_link"
              required
              className="inputField "
              value={inputs.github_link || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="address" className="inputLabel text-slate-800">
              Address
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="address"
              placeholder="Address"
              name="address"
              required
              className="inputField "
              value={inputs.address || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="copy_right" className="inputLabel text-slate-800">
              Copy Right
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="copy_right"
              placeholder="Copy Right"
              name="copy_right"
              required
              className="inputField "
              value={inputs.copy_right || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="google_map" className="inputLabel text-slate-800">
              Google Map
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="google_map"
              placeholder="Google Map"
              name="google_map"
              required
              className="inputField "
              value={inputs.google_map || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="project_done" className="inputLabel text-slate-800">
              Project Done
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="project_done"
              placeholder="Project Done"
              name="project_done"
              required
              className="inputField "
              value={inputs.project_done || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="happy_client" className="inputLabel text-slate-800">
              Happy Client
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="happy_client"
              placeholder="Happy Client"
              name="happy_client"
              required
              className="inputField "
              value={inputs.happy_client || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="award" className="inputLabel text-slate-800">
              Award
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="award"
              placeholder="Award"
              name="award"
              required
              className="inputField "
              value={inputs.award || ""}
              onChange={handleChange}
            />
          </div>

          <div className="col-start-1 col-end-3">
            <label htmlFor="short_desc" className="inputLabel text-slate-800">
              Short Description
              <span className="text-red-600"> *</span>
            </label>
            <textarea
              id="short_desc"
              placeholder="Short Description"
              name="short_desc"
              required
              className="h-[100px] inputField"
              value={inputs.short_desc || ""}
              onChange={handleChange}
            ></textarea>
          </div>

          <div className="col-start-1 col-end-3">
            <label htmlFor="long_desc" className="inputLabel text-slate-800">
              Long Description
              <span className="text-red-600"> *</span>
            </label>
            <textarea
              id="long_desc"
              placeholder="Long Description"
              name="long_desc"
              required
              className="h-[300px] inputField"
              value={inputs.long_desc || ""}
              onChange={handleChange}
            ></textarea>
          </div>
        </div>

        <div className="flex items-center gap-2 mt-4 justify-end col-start-1 col-end-3">
          <button
            disabled={isLoading ? true : false}
            type="submit"
            className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
          >
            {isLoading ? "Loading..." : "Update"}
          </button>
        </div>
      </form>
    );
  return (
    <>
      <PageLabel title="setting"></PageLabel>
      <DashboardBody>{content}</DashboardBody>
    </>
  );
};

export default DashboardSetting;
