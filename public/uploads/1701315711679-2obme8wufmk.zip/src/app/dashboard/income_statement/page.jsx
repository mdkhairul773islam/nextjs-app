"use client";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import IncomeReport from "@/components/Dashboard/IncomeStatement/IncomeReport";
import ExpenseReport from "@/components/Dashboard/IncomeStatement/ExpenseReport";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const IncomeStatement = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/income_statement"));
  }, [dispatch]);

  const balance = 0 - 0;

  return (
    <>
      <PageLabel title="income_statement">
        <h2
          className={`${
            balance > 0 ? "bg-green-700" : "bg-red-600"
          }  text-white text-xl shadow-md font-mono p-1 px-3`}
        >
          Balance: {balance}
        </h2>
      </PageLabel>
      <DashboardBody>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <ExpenseReport />
          <IncomeReport />
        </div>
      </DashboardBody>
    </>
  );
};

export default IncomeStatement;
