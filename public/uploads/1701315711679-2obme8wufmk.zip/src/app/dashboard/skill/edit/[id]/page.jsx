"use client";
import { useEffect, useState } from "react";

import Link from "next/link";
import toastify from "@/utils/toastify";
import { useRouter } from "next/navigation";
import PageLabel from "@/components/Dashboard/PageLabel";
import {
  useEditSkillMutation,
  useGetSkillQuery,
} from "@/redux/features/skill/skillApi";
import { useDispatch } from "react-redux";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import TableError from "@/components/Dashboard/ui/TableError";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const UpdateSkill = ({ params }) => {
  const [inputs, setInputs] = useState({});
  const router = useRouter();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/skill"));
  }, [dispatch]);

  const {
    data: skill,
    isSuccess: skillGetSuccess,
    isLoading: skillLoading,
    isError: skillError,
  } = useGetSkillQuery(params.id);
  const [editSkill, { isSuccess, isLoading, isError }] = useEditSkillMutation();

  useEffect(() => {
    if (isSuccess) {
      toastify.success("Skill Updated Successfully!");
      setInputs({});
      router.push("/dashboard/skill");
    }

    if (isError) {
      toastify.error("There was an error!");
    }
  }, [isSuccess, isError, router]);

  useEffect(() => {
    if (skillGetSuccess) {
      setInputs(skill);
    }
  }, [skillGetSuccess, skill]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    editSkill({ id: params.id, data: inputs });
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  let content = null;

  if (skillLoading)
    content = <div className="bg-gray-300 animate-pulse h-10"></div>;

  if (!skillLoading && skillError)
    content = <TableError message="Something is error!" />;

  if (!skillLoading && !skillError && skill) {
    content = (
      <form className="w-full" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-3">
          <div className="">
            <label htmlFor="name" className="inputLabel">
              Skill Name
              <span className="text-red-600"> *</span>
            </label>
            <input
              type="text"
              id="name"
              placeholder="Skill Name"
              name="name"
              required
              className="inputField "
              value={inputs.name || ""}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="flex items-center mt-3 gap-2 justify-end col-start-1 col-end-3">
          <Link
            href="/dashboard/skill"
            className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 cursor-pointer"
          >
            Cancel
          </Link>
          <button
            disabled={isLoading}
            type="submit"
            className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2"
          >
            {isLoading ? "Loading..." : "Update"}
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="">
      <PageLabel title="skill"></PageLabel>
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default UpdateSkill;
