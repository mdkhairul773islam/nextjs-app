"use client";
import Modal from "@/components/Modal";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import PageLabel from "@/components/Dashboard/PageLabel";
import AllSkill from "@/components/Dashboard/Skill/AllSkill";
import AddSkill from "@/components/Dashboard/Skill/AddSkill";
import {
  activeModal,
  changPath,
} from "@/redux/features/dashboard/dashboardSlice";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import { FiFolderPlus } from "react-icons/fi";

const Skill = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/skill"));
  }, [dispatch]);

  return (
    <>
      <PageLabel title="skill">
        <button
          onClick={() => dispatch(activeModal())}
          className="bg-teal-600 hover:bg-teal-700 rounded-md text-white h-8 w-8 flex items-center justify-center"
          title="Add Skill"
        >
          <FiFolderPlus />
        </button>
      </PageLabel>

      <Modal>
        <AddSkill />
      </Modal>

      <DashboardBody>
        <AllSkill />
      </DashboardBody>
    </>
  );
};

export default Skill;
