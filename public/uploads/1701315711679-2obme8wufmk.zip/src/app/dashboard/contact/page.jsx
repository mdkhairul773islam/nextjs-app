"use client";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import ContactTr from "@/components/Dashboard/Contact/ContactTr";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useGetContactsQuery } from "@/redux/features/contact/contactApi";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";
import TableEmpty from "@/components/Dashboard/ui/TableEmpty";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";

const Contact = () => {
  const { data: contacts, isLoading, isError } = useGetContactsQuery();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/contact"));
  }, [dispatch]);

  // decide what to render
  let content = null;

  if (isLoading) content = <TableSkeleton />;

  if (!isLoading && isError)
    content = <TableError message="Something is Error" />;

  if (!isLoading && !isError && contacts?.length === 0)
    content = <TableEmpty message="No Contact Found!" />;

  if (!isLoading && !isError && contacts.length > 0) {
    content = (
      <div className="w-full overflow-x-auto">
        <table className="w-full">
          <thead className="tableHead">
            <tr>
              <th className="p-2">SL</th>
              <th className="p-2">Name</th>
              <th className="p-2">Email</th>
              <th className="p-2">Description</th>
              <th className="p-2">Status</th>
              <th className="p-2w-[40px] text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {contacts?.map((contact, index) => {
              return (
                <ContactTr key={contact.id} contact={contact} index={index} />
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div>
      <PageLabel title="contact" />
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default Contact;
