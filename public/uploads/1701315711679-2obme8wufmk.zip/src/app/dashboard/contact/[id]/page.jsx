"use client";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import PageLabel from "@/components/Dashboard/PageLabel";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import {
  useEditContactMutation,
  useGetContactQuery,
} from "@/redux/features/contact/contactApi";
import Link from "next/link";
import DashboardBody from "@/components/Dashboard/DashboardLayout/DashboardBody/DashboardBody";
import TableSkeleton from "@/components/Dashboard/ui/TableSkeleton";
import TableError from "@/components/Dashboard/ui/TableError";

const ViewContact = ({ params }) => {
  const [editContact, { isLoading: editLoading }] = useEditContactMutation();

  const { data: contact, isLoading, isError } = useGetContactQuery(params.id);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard/contact"));
  }, [dispatch]);

  useEffect(() => {
    editContact({ id: params.id, data: { status: "true" } });
  }, [params.id, editContact]);

  let content = null;
  if (isLoading) content = <TableSkeleton />;
  if (!isLoading && isError)
    content = <TableError message="Something is Error!" />;
  if (!isLoading && !isError && contact?.id)
    content = (
      <div className="inline-flex items-start flex-col gap-2">
        <p>
          <span className="font-bold w-28 inline-block">Name:</span>
          {contact?.name}
        </p>
        <p>
          <span className="font-bold w-28 inline-block">Email:</span>
          {contact?.email}
        </p>
        <p>
          <span className="font-bold w-28 inline-block">Status:</span>
          {contact?.status == "true" ? "Received" : "Pending"}
        </p>
        <p>
          <span className="font-bold w-28 inline-block">Description:</span>
          {contact?.description}
        </p>
        <Link href={"/dashboard/contact"} className="primaryBtn mt-4">
          Show All Contact
        </Link>
      </div>
    );
  return (
    <div>
      <PageLabel title="contact" />
      <DashboardBody>{content}</DashboardBody>
    </div>
  );
};

export default ViewContact;
