"use client";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { TbMoneybag } from "react-icons/tb";
import { GiPayMoney } from "react-icons/gi";
import { BiSolidContact } from "react-icons/bi";
import { MdSettingsSuggest } from "react-icons/md";
import { GiVibratingShield } from "react-icons/gi";
import { FaBlog, FaServicestack } from "react-icons/fa";
import { AiOutlineFundProjectionScreen } from "react-icons/ai";

import { useGetBlogsQuery } from "@/redux/features/blog/blogApi";
import { useGetSkillsQuery } from "@/redux/features/skill/skillApi";
import { changPath } from "@/redux/features/dashboard/dashboardSlice";
import { useGetIncomesQuery } from "@/redux/features/income/incomeApi";
import { useGetContactsQuery } from "@/redux/features/contact/contactApi";
import { useGetServicesQuery } from "@/redux/features/service/serviceApi";
import { useGetExpensesQuery } from "@/redux/features/expense/expenseApi";
import { useGetPortfoliosQuery } from "@/redux/features/portfolio/portfolioApi";
import { useGetTestimonialsQuery } from "@/redux/features/testimonial/testimonialApi";

const Dashboard = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(changPath("/dashboard"));
  }, [dispatch]);

  const { data: income } = useGetIncomesQuery();
  const { data: portfolio } = useGetPortfoliosQuery();
  const { data: contact } = useGetContactsQuery();
  const { data: expense } = useGetExpensesQuery();
  const { data: testimonials } = useGetTestimonialsQuery();
  const { data: blogs } = useGetBlogsQuery();
  const { data: skills } = useGetSkillsQuery();
  const { data: services } = useGetServicesQuery();

  const dashboardCardData = [
    {
      data: portfolio,
      label: "Portfolio",
      href: "portfolio",
      icon: <AiOutlineFundProjectionScreen />,
    },
    {
      data: testimonials,
      label: "Testimonials",
      href: "testimonial",
      icon: <GiVibratingShield />,
    },
    {
      data: contact,
      label: "Contact",
      href: "contact",
      icon: <BiSolidContact />,
    },
    {
      data: income,
      label: "Total Income",
      href: "income",
      icon: <TbMoneybag />,
    },
    {
      data: expense,
      label: "Total Expense",
      href: "expense",
      icon: <GiPayMoney />,
    },
    {
      data: "balance",
      label: "Balance",
      href: "expense",
      icon: <GiPayMoney />,
    },
    {
      data: blogs,
      label: "Blog",
      href: "blog",
      icon: <FaBlog />,
    },
    {
      data: skills,
      label: "Skill",
      href: "skill",
      icon: <MdSettingsSuggest />,
    },
    {
      data: services,
      label: "Services",
      href: "service",
      icon: <FaServicestack />,
    },
  ];

  const totalIncome = income?.reduce((accumulator, inc) => {
    return accumulator + inc.amount;
  }, 0);

  const totalExpense = expense?.reduce((accumulator, exp) => {
    return accumulator + exp.amount;
  }, 0);

  const balance = totalIncome - totalExpense;

  return (
    <>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-5">
        {dashboardCardData.map(({ data, href, icon, label }, index) => (
          <div
            key={index}
            className="px-3 py-6 rounded-s-lg border-l-4 border-teal-600 shadow-lg duration-300 hover:shadow-none bg-teal-600/20 flex items-center  gap-3 "
          >
            <div className="rounded-sm shadow-md h-16 w-16 flex items-center justify-center bg-white text-teal-600 text-4xl">
              {icon}
            </div>
            <div>
              {data && (
                <h1 className="text-2xl text-slate-700 font-bold">
                  {data == income
                    ? totalIncome
                    : data == "balance"
                    ? balance
                    : data == expense
                    ? totalExpense
                    : data.length}
                </h1>
              )}
              <h2 className="text-base uppercase tracking-[3px] text-teal-600">
                {label}
              </h2>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Dashboard;
