"use client";

export default function RootLayout({ children }) {
  return (
    <>
      <div className="fixedBg"></div>
      {children}
    </>
  );
}
