"use client";
import { useState } from "react";

const LoginForm = () => {
  const [inputs, setInputs] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs((prevState) => ({ ...prevState, [name]: value }));
  };

  return (
    <div className="container px-4 w-[500px] my-20 mx-auto shadow-lg bg-[#112240] py-8 border-t-4 border-t-teal-600 rounded-xl">
      <form className="w-full block" onSubmit={handleSubmit}>
        <h3 className="text-center text-3xl mb-8 font-mono font-bold">
          Admin Login
        </h3>
        <div className="flex flex-col gap-4">
          <div>
            <label htmlFor="email">
              Email <span className="text-red-600">*</span>
            </label>
            <input
              type="email"
              name="email"
              id="email"
              required
              className="w-full mt-2 p-3 border border-teal-500/40 focus:border-teal-500 bg-[#0A192F]  outline-none"
              placeholder="Enter Your Name"
              value={inputs.email || ""}
              onChange={handleChange}
            />
          </div>
          <div>
            <label htmlFor="password">
              Password <span className="text-red-600">*</span>
            </label>
            <input
              type="password"
              name="password"
              id="password"
              required
              className="w-full mt-2 p-3 border border-teal-500/40 focus:border-teal-500 bg-[#0A192F] outline-none"
              placeholder="Enter Your Email"
              value={inputs.password || ""}
              onChange={handleChange}
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="primaryBtn w-full"
          >
            {isLoading ? "Loading..." : "Submit"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default LoginForm;
