import { URL } from "@/utils/helper";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const apiSlice = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: URL,
  }),
  tagTypes: [
    "Contacts",
    "Contact",
    "Testimonials",
    "Testimonial",
    "Services",
    "Service",
    "Portfolios",
    "Portfolio",
    "Skills",
    "Skill",
    "Expenses",
    "Expense",
    "Incomes",
    "Income",
    "Settings",
    "Setting",
    "Experiences",
    "Experience",
    "Blogs",
    "Blog",
    "Interviews",
    "Interview",
    "Posts",
    "Post",
  ],
  endpoints: (builder) => ({}),
});

export default apiSlice;
