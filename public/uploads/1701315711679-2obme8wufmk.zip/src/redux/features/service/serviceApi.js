import { apiSlice } from "../api/apiSlice";

export const serviceApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getServices: builder.query({
      query: () => "/service",
      providesTags: ["Services"],
    }),

    getService: builder.query({
      query: (id) => `/service/${id}`,
      providesTags: (result, error, arg) => [{ type: "Service", id: arg }],
    }),

    addService: builder.mutation({
      query: (data) => ({
        url: "/service",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Services"],
    }),

    editService: builder.mutation({
      query: ({ id, data }) => ({
        url: `/service/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Services",
        { type: "Service", id: arg.id },
      ],
    }),

    deleteService: builder.mutation({
      query: (id) => ({
        url: `/service/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Services"],
    }),
  }),
});

export const {
  useGetServiceQuery,
  useGetServicesQuery,
  useAddServiceMutation,
  useDeleteServiceMutation,
  useEditServiceMutation,
} = serviceApi;
