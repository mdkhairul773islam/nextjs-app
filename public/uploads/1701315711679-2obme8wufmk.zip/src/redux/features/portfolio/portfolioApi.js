import { apiSlice } from "../api/apiSlice";

export const portfolioApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPortfolios: builder.query({
      query: () => "/portfolio",
      providesTags: ["Portfolios"],
    }),

    getPortfolio: builder.query({
      query: (id) => `/portfolio/${id}`,
      providesTags: (result, error, arg) => [{ type: "Portfolio", id: arg }],
    }),

    addPortfolio: builder.mutation({
      query: (data) => ({
        url: "/portfolio",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Portfolios"],
    }),

    editPortfolio: builder.mutation({
      query: ({ id, data }) => ({
        url: `/portfolio/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Portfolios",
        { type: "Portfolio", id: arg.id },
      ],
    }),

    deletePortfolio: builder.mutation({
      query: (id) => ({
        url: `/portfolio/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Portfolios"],
    }),
  }),
});

export const {
  useGetPortfolioQuery,
  useGetPortfoliosQuery,
  useAddPortfolioMutation,
  useDeletePortfolioMutation,
  useEditPortfolioMutation,
} = portfolioApi;
