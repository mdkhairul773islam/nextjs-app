import { apiSlice } from "../api/apiSlice";

export const incomeApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getIncomes: builder.query({
      query: () => "/income",
      providesTags: ["Incomes"],
    }),

    getIncome: builder.query({
      query: (id) => `/income/${id}`,
      providesTags: (result, error, arg) => [{ type: "Income", id: arg }],
    }),

    addIncome: builder.mutation({
      query: (data) => ({
        url: "/income",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Incomes"],
    }),

    editIncome: builder.mutation({
      query: ({ id, data }) => ({
        url: `/income/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Incomes",
        { type: "Income", id: arg.id },
      ],
    }),

    deleteIncome: builder.mutation({
      query: (id) => ({
        url: `/income/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Incomes"],
    }),
  }),
});

export const {
  useGetIncomeQuery,
  useGetIncomesQuery,
  useAddIncomeMutation,
  useDeleteIncomeMutation,
  useEditIncomeMutation,
} = incomeApi;
