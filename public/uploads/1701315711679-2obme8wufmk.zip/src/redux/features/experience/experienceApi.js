import { apiSlice } from "../api/apiSlice";

export const experienceApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getExperiences: builder.query({
      query: () => "/experience",
      providesTags: ["Experiences"],
    }),

    getExperience: builder.query({
      query: (id) => `/experience/${id}`,
      providesTags: (result, error, arg) => [{ type: "Experience", id: arg }],
    }),

    addExperience: builder.mutation({
      query: (data) => ({
        url: "/experience",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Experiences"],
    }),

    editExperience: builder.mutation({
      query: ({ id, data }) => ({
        url: `/experience/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Experiences",
        { type: "Experience", id: arg.id },
      ],
    }),

    deleteExperience: builder.mutation({
      query: (id) => ({
        url: `/experience/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Experiences"],
    }),
  }),
});

export const {
  useGetExperienceQuery,
  useGetExperiencesQuery,
  useAddExperienceMutation,
  useDeleteExperienceMutation,
  useEditExperienceMutation,
} = experienceApi;
