import { apiSlice } from "../api/apiSlice";

export const interviewApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getInterviews: builder.query({
      query: () => "/interview",
      providesTags: ["Interviews"],
    }),

    getInterview: builder.query({
      query: (id) => `/interview/${id}`,
      providesTags: (result, error, arg) => [{ type: "Interview", id: arg }],
    }),

    addInterview: builder.mutation({
      query: (data) => ({
        url: "/interview",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Interviews"],
    }),

    editInterview: builder.mutation({
      query: ({ id, data }) => ({
        url: `/interview/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Interviews",
        { type: "Interview", id: arg.id },
      ],
    }),

    deleteInterview: builder.mutation({
      query: (id) => ({
        url: `/interview/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Interviews"],
    }),
  }),
});

export const {
  useGetInterviewQuery,
  useGetInterviewsQuery,
  useAddInterviewMutation,
  useDeleteInterviewMutation,
  useEditInterviewMutation,
} = interviewApi;
