import { createSlice } from "@reduxjs/toolkit";

const dashboardSlice = createSlice({
  name: "dashboard",
  initialState: {
    pathname: "",
    modal: false,
  },
  reducers: {
    changPath: (state, action) => {
      state.pathname = action.payload;
    },
    activeModal: (state) => {
      state.modal = !state.modal;
    },
  },
});

export const { changPath, activeModal } = dashboardSlice.actions;
export default dashboardSlice.reducer;
