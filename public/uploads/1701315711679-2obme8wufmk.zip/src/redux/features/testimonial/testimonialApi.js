import { apiSlice } from "../api/apiSlice";

export const testimonialApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getTestimonials: builder.query({
      query: () => "/testimonials",
      providesTags: ["Testimonials"],
    }),

    getTestimonial: builder.query({
      query: (id) => `/testimonials/${id}`,
      providesTags: (result, error, arg) => [{ type: "Testimonial", id: arg }],
    }),

    addTestimonial: builder.mutation({
      query: (data) => ({
        url: "/testimonials",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Testimonials"],
    }),

    editTestimonial: builder.mutation({
      query: ({ id, data }) => ({
        url: `/testimonials/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Testimonials",
        { type: "Testimonial", id: arg.id },
      ],
    }),

    deleteTestimonial: builder.mutation({
      query: (id) => ({
        url: `/testimonials/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Testimonials"],
    }),
  }),
});

export const {
  useGetTestimonialQuery,
  useGetTestimonialsQuery,
  useAddTestimonialMutation,
  useDeleteTestimonialMutation,
  useEditTestimonialMutation,
} = testimonialApi;
