import { createSlice } from "@reduxjs/toolkit";

const homeSlice = createSlice({
  name: "home",
  initialState: {
    setting: null,
  },
  reducers: {
    siteInfo: (state, action) => {
      state.setting = action.payload;
    },
  },
});

export const { siteInfo } = homeSlice.actions;
export default homeSlice.reducer;
