import { apiSlice } from "../api/apiSlice";

export const skillApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getSkills: builder.query({
      query: () => "/skill",
      providesTags: ["Skills"],
    }),

    getSkill: builder.query({
      query: (id) => `/skill/${id}`,
      providesTags: (result, error, arg) => [{ type: "Skill", id: arg }],
    }),

    addSkill: builder.mutation({
      query: (data) => ({
        url: "/skill",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Skills"],
    }),

    editSkill: builder.mutation({
      query: ({ id, data }) => ({
        url: `/skill/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Skills",
        { type: "Skill", id: arg.id },
      ],
    }),

    deleteSkill: builder.mutation({
      query: (id) => ({
        url: `/skill/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Skills"],
    }),
  }),
});

export const {
  useGetSkillQuery,
  useGetSkillsQuery,
  useAddSkillMutation,
  useDeleteSkillMutation,
  useEditSkillMutation,
} = skillApi;
