import { apiSlice } from "../api/apiSlice";

export const settingApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getSettings: builder.query({
      query: () => "/setting",
      providesTags: ["Settings"],
    }),

    getSetting: builder.query({
      query: (id) => `/setting/${id}`,
      providesTags: (result, error, arg) => [{ type: "Setting", id: arg }],
    }),

    addSetting: builder.mutation({
      query: (data) => ({
        url: "/setting",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Settings"],
    }),

    editSetting: builder.mutation({
      query: ({ id, data }) => ({
        url: `/setting/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Settings",
        { type: "Setting", id: arg.id },
      ],
    }),

    deleteSetting: builder.mutation({
      query: (id) => ({
        url: `/setting/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Settings"],
    }),
  }),
});

export const {
  useGetSettingQuery,
  useGetSettingsQuery,
  useAddSettingMutation,
  useDeleteSettingMutation,
  useEditSettingMutation,
} = settingApi;
