import { apiSlice } from "../api/apiSlice";

export const expenseApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getExpenses: builder.query({
      query: () => "/expense",
      providesTags: ["Expenses"],
    }),

    getExpense: builder.query({
      query: (id) => `/expense/${id}`,
      providesTags: (result, error, arg) => [{ type: "Expense", id: arg }],
    }),

    addExpense: builder.mutation({
      query: (data) => ({
        url: "/expense",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Expenses"],
    }),

    editExpense: builder.mutation({
      query: ({ id, data }) => ({
        url: `/expense/${id}`,
        method: "PATCH",
        body: data,
      }),
      invalidatesTags: (result, error, arg) => [
        "Expenses",
        { type: "Expense", id: arg.id },
      ],
    }),

    deleteExpense: builder.mutation({
      query: (id) => ({
        url: `/expense/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Expenses"],
    }),
  }),
});

export const {
  useGetExpensesQuery,
  useGetExpenseQuery,
  useEditExpenseMutation,
  useAddExpenseMutation,
  useDeleteExpenseMutation,
} = expenseApi;
